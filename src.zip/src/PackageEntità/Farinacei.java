package PackageEntit�;

public class Farinacei extends Prodotto{
	
	public Farinacei() {
	}

}
