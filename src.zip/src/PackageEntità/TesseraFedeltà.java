package PackageEntit�;
public class TesseraFedelt� {
	
	private String NumeroTessera;
	private int NumeroPunti;
	public Cliente PossessoreTessera;
	
	
	public String getNumeroTessera() {
		return NumeroTessera;
	}
	public void setNumeroTessera(String numeroTessera) {
		NumeroTessera = numeroTessera;
	}
	public int getNumeroPunti() {
		return NumeroPunti;
	}
	public void setNumeroPunti(int numeroPunti) {
		NumeroPunti = numeroPunti;
	}
	
	
	public void StampaDettagliTessera(String numeroTessera) {	
	}
	public void AggiungiPunti(TesseraFedelt� Tessera) {	
	}
	

	public TesseraFedelt�() {
		// TODO Auto-generated constructor stub
	}

}
