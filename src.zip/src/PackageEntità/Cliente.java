package PackageEntit�;

import PackageController.Controller;
import PackageDAO.ClienteDAO;

public class Cliente {

	private String username;
	private String password;
	public Carrello IlMioCarrello;
	public TesseraFedelt� tessera = new TesseraFedelt�();

	
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void CalcolaPunti(double PrezzoFinale) {
	}
	
	public Cliente() {
		// TODO Auto-generated constructor stub
	}

}
