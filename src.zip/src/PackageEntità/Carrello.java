package PackageEntit�;

public class Carrello {
	
	public Carrello() {
	}
	private double PrezzoTotale;
	public Cliente Acquirente = new Cliente();
	

	public double getPrezzoTotale() {
		return PrezzoTotale;
	}
	public void setPrezzoTotale(double prezzoTotale) {
		PrezzoTotale = prezzoTotale;
	}

}
