package PackageEntit�;

import java.util.LinkedList;

public class Carrello {
	
	public Carrello() {
	}
	
	private double PrezzoTotale;
	public Cliente Acquirente = new Cliente();
	LinkedList<Prodotto> ProdottiInCarrello = new LinkedList<Prodotto>();
	

	public double getPrezzoTotale() {
		return PrezzoTotale;
	}
	public void setPrezzoTotale(double prezzoTotale) {
		PrezzoTotale = prezzoTotale;
	}

}
