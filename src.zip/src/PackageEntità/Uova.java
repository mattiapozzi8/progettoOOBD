package PackageEntit�;
import java.util.*;

public class Uova extends Prodotto{

	private Date DataDiRaccolta;
	private Date DataDiDeposizione;
	
	@Override
	public Date getDataDiRaccolta() {
		return DataDiRaccolta;
	}
	@Override
	public void setDataDiRaccolta(Date dataDiRaccolta) {
		DataDiRaccolta = dataDiRaccolta;
	}
	@Override
	public Date getDataDiDeposizione() {
		return DataDiDeposizione;
	}
	@Override
	public void setDataDiDeposizione(Date dataDiDeposizione) {
		DataDiDeposizione = dataDiDeposizione;
	}
	
	@Override
	public void CalcolaPrezzo() {
		// TODO Auto-generated method stub
		super.CalcolaPrezzo();
	}
	
	public Uova() {
		// TODO Auto-generated constructor stub
	}

}
