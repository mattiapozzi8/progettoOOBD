package PackageEntit�;
import java.util.*;

public class Frutta extends Prodotto{
	
	private Date DataDiRaccolta;
	private String Modalit�DiConservazione;
	
	@Override
	public Date getDataDiRaccolta() {
		return DataDiRaccolta;
	}
	@Override
	public void setDataDiRaccolta(Date dataDiRaccolta) {
		DataDiRaccolta = dataDiRaccolta;
	}
	@Override
	public String getModalit�DiConservazione() {
		System.out.println(""+Modalit�DiConservazione);
		return Modalit�DiConservazione;
	}
	@Override
	public void setModalit�DiConservazione(String modalit�DiConservazione) {
		Modalit�DiConservazione = modalit�DiConservazione;
	}


	@Override
	public void CalcolaPrezzo() {
		// TODO Auto-generated method stub
		super.CalcolaPrezzo();
	}
	
	public Frutta() {
		// TODO Auto-generated constructor stub
	}

}
