package PackageEntit�;
import java.util.*;

public class Confezionati extends Prodotto{
	
	private Date DataConfezionamento;
	
	@Override
	public Date getDataConfezionamento() {
		return DataConfezionamento;
	}
	@Override
	public void setDataConfezionamento(Date dataConfezionamento) {
		DataConfezionamento = dataConfezionamento;
	}


	public Confezionati() {
	}

}
