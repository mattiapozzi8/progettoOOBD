package PackageDAO;
import java.sql.*;
import java.util.LinkedList;

import PackageEntit�.Prodotto;

public class ProdottoDAO {
	
	LinkedList<Prodotto> prodotti = new LinkedList<Prodotto>();
	
	public ProdottoDAO(){
	try {
		Class.forName("org.postgresql.Driver");
	} catch(ClassNotFoundException e) {
		System.out.println("Class not found!\n"+e);
	}
	
	try {
		
		Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/progetto", "postgres", "basididati");
		Statement st = conn.createStatement();
		ResultSet rs = st.executeQuery("SELECT * FROM prodotto;");
	
		
		while(rs.next()) {
			
			Prodotto p = new Prodotto();
			
			p.setNomeProdotto(rs.getString("nome_prodotto"));
			p.setTipo(rs.getString("tipo"));
			p.setMarca(rs.getString("marca"));
			p.setCodiceID(rs.getString("codice_id"));
			p.setPrezzoAlKilo(rs.getDouble("prezzo"));
     		p.setDataDiScadenza(rs.getDate("data_scadenza"));
			p.setDisponibilit�(rs.getInt("disponibilita"));
			p.setDataDiRaccolta(rs.getDate("data_raccolta"));
			p.setModalit�DiConservazione(rs.getString("modalita_conservazione"));
			p.setDataConfezionamento(rs.getDate("data_confezionamento"));
			p.setDataDiProduzione(rs.getDate("data_produzione"));
			p.setPaeseDiCondizionamento(rs.getString("paese_condizionamento"));
			p.setDataDiDeposizione(rs.getDate("data_deposizione"));
			
			prodotti.add(p);
		
		}
		
			rs.close();
			st.close();
			conn.close();
		
	} catch(SQLException e) {
		System.out.println("SQL Exception\n"+e);
	}
	

}
	
	public LinkedList<Prodotto> ConnessioneDB(Prodotto prodotto) {
		
		return prodotti;
	}
	}