package PackageDAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class CarrelloDAO {
	
	public void ScalaDisp(Double quantita, String nome_prodotto) {
		
		try {
			Class.forName("org.postgresql.Driver");
		} catch(ClassNotFoundException e) {
			System.out.println("Class not found:\n"+e);
		}
		
		try {
			Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/progetto", "postgres", "basididati");
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("UPDATE prodotto SET disponibilita = disponibilita - "+quantita+" WHERE prodotto.nome_prodotto = '"+nome_prodotto+"'");
			
			
			rs.close();
			st.close();
			conn.close();
			
		} catch(SQLException e) {		
		}
		
	}
	
	public String TipoDiProdotto(String nome_prodotto) {
		
		String tipo = null;
		
		try {
			Class.forName("org.postgresql.Driver");
		} catch(ClassNotFoundException e) {
			System.out.println("Class not found:\n"+e);
		}
		
		try {
			Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/progetto", "postgres", "basididati");
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("SELECT tipo FROM prodotto WHERE nome_prodotto = '"+nome_prodotto+"';");
			
			while(rs.next()) {
				tipo = rs.getString("tipo");
			}
			
			rs.close();
			st.close();
			conn.close();
			
			return tipo;
		
	} catch(SQLException e) {	
		return "";
	}
		
	}
	
	public double PrezzoDelProdotto(String nome_prodotto) {
		
		double prezzo = 0.0;
		
		try {
			Class.forName("org.postgresql.Driver");
		} catch(ClassNotFoundException e) {
			System.out.println("Class not found:\n"+e);
		}
		
		try {
			Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/progetto", "postgres", "basididati");
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("SELECT prezzo FROM prodotto WHERE nome_prodotto = '"+nome_prodotto+"';");
			
			while(rs.next()) {
				prezzo = rs.getDouble("prezzo");
			}
			
			rs.close();
			st.close();
			conn.close();
			
			return prezzo;
		
	} catch(SQLException e) {	
		return 0.0;
	}
		
	}
	
}


