package PackageDAO;

import java.sql.*;

import PackageEntit�.Cliente;


public class ClienteDAO {
	
		public int flag=0;
		public Cliente cliente = new Cliente();

		public void controllo(String username, String password) {
		
		try {
			Class.forName("org.postgresql.Driver");
		} catch(ClassNotFoundException e) {
			System.out.println("Class not found:\n"+e);
		}
		
		try {
			Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/progetto", "postgres", "basididati");
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("SELECT * from credenziali;");
				
				while(rs.next()) {
					if(rs.getString("username").equals(username)==true && rs.getString("password").equals(password)==true) {
						flag=1;
						break;
					} 
				}
			
			
			rs.close();
			st.close();
			conn.close();
			
		} catch(SQLException e) {
			System.out.println("SQL Exception:\n"+e);
		}
		
	}
	
	public boolean exists() {
		
		if(flag==1) {
			return true;
		} else {
			return false;
		}
}
	
	public void RegistraCliente(String username, String password) {
		
		try {
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println("Class not found:\n"+e);
		}
		
		try {
			
			Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/progetto", "postgres", "basididati");
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("INSERT into credenziali(username, password, punti) VALUES ('"+username+"', '"+password+"', 0);");
			
			rs.close();
			st.close();
			conn.close();
			
		} catch(SQLException e) {
		}
		
	}
	
	public void RegistraTessera(String username) {
		
		try {
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println("Class not found:\n"+e);
		}
		
		try {
			
			Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/progetto", "postgres", "basididati");
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("INSERT  into tessera(username, punti_frutta, punti_verdura, punti_farinacei, punti_latticini, punti_uova, punti_confezionati) VALUES ('"+username+"', 0, 0, 0, 0, 0, 0);");
			
			rs.close();
			st.close();
			conn.close();
			
		} catch(SQLException e) {
		}
		
	}
	
	public boolean TrovaCliente(String username) {
		
		boolean trovato = false;
		
		try {
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println("Class not found:\n"+e);
		}
		
		try {
			
			Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/progetto", "postgres", "basididati");
			Statement st = conn.createStatement();
			ResultSet rs= st.executeQuery("SELECT * from credenziali;");
			
			while(rs.next()) {
				if(rs.getString("username").equals(username)==true) {
					trovato = true;
					break;
				} 
			}
			
			rs.close();
			st.close();
			conn.close();
			
			return trovato;
			
		} catch(SQLException e) {
			return trovato;
		}
		
	}
	
	public void AssegnaPunti(int punti_fedelta, String user) {
		
		try {
			Class.forName("org.postgresql.Driver");
		} catch(ClassNotFoundException e) {
			System.out.println("Class not found:\n"+e);
		}
		
		try {
			Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/progetto", "postgres", "basididati");
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("UPDATE credenziali SET punti = punti + "+punti_fedelta+" WHERE credenziali.username = '"+user+"'");
			
			
			rs.close();
			st.close();
			conn.close();
			
		} catch(SQLException e) {		
		}
		
	}
	
	public int InfoCliente(String user) {
		
		int punti = 0;
		
		try {
			Class.forName("org.postgresql.Driver");
		} catch(ClassNotFoundException e) {
			System.out.println("Class not found:\n"+e);
		}
		
		try {
			Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/progetto", "postgres", "basididati");
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("SELECT * from credenziali WHERE username = '"+user+"'");
			
			while(rs.next()) {
			punti = rs.getInt("punti");
			}
			
			rs.close();
			st.close();
			conn.close();
			
			return punti;
			
			
		} catch(SQLException e) {
			return 0;
		}
		
	}
	
	public void AssegnaPuntiPerTipo(String tipo, int punti, String user) {
		
		try {
			Class.forName("org.postgresql.Driver");
		} catch(ClassNotFoundException e) {
			System.out.println("Class not found:\n"+e);
		}
		
		try {
			Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/progetto", "postgres", "basididati");
			Statement st = conn.createStatement();
			
			if(tipo=="Frutta") {
				ResultSet rs = st.executeQuery("UPDATE tessera SET punti_frutta = punti_frutta + "+punti+" WHERE tessera.username = '"+user+"';");
				rs.close();
			} else {
				if(tipo=="Verdura") {
					ResultSet rs = st.executeQuery("UPDATE tessera SET punti_vedura = punti_verdura + "+punti+" WHERE tessera.username = '"+user+"';");
					rs.close();
				} else {
					if(tipo=="Farinacei") {
						ResultSet rs = st.executeQuery("UPDATE tessera SET punti_farinacei = punti_farinacei + "+punti+" WHERE tessera.username = '"+user+"';");
						rs.close();
					} else {
						if(tipo=="Latticini") {
							ResultSet rs = st.executeQuery("UPDATE tessera SET punti_latticini = punti_latticini + "+punti+" WHERE tessera.username = '"+user+"';");
							rs.close();
						} else {
							if(tipo=="Uova") {
								ResultSet rs = st.executeQuery("UPDATE tessera SET punti_uova = punti_uova + "+punti+" WHERE tessera.username = '"+user+"';");
								rs.close();
							} else {
								if(tipo=="Confezionati") {
									ResultSet rs = st.executeQuery("UPDATE tessera SET punti_confezionati = punti_confezionati + "+punti+" WHERE tessera.username = '"+user+"';");
									rs.close();
								}
							}
						}
					}
				}
			}
			
			st.close();
			conn.close();
			
			
		} catch(SQLException e) {
		}
		
	}
		
}
