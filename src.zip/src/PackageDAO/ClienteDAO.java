package PackageDAO;

import java.sql.*;

import PackageEntit�.Cliente;


public class ClienteDAO {
	
		public int flag=0;
		public Cliente cliente = new Cliente();

		public void controllo(String username, String password) {
		
		try {
			Class.forName("org.postgresql.Driver");
		} catch(ClassNotFoundException e) {
			System.out.println("Class not found:\n"+e);
		}
		
		try {
			Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/credenzialidb", "postgres", "basididati");
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("SELECT * from credenziali;");
				
				while(rs.next()) {
					if(rs.getString("username").equals(username)==true && rs.getString("password").equals(password)==true) {
						flag=1;
						break;
					} 
				}
			
			
			rs.close();
			st.close();
			conn.close();
			
		} catch(SQLException e) {
			System.out.println("SQL Exception:\n"+e);
		}
		
	}
	
	public boolean exists() {
		
		if(flag==1) {
			return true;
		} else {
			return false;
		}
}
	
	public void RegistraCliente(String username, String password) {
		
		try {
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println("Class not found:\n"+e);
		}
		
		try {
			
			Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/credenzialidb", "postgres", "basididati");
			Statement st = conn.createStatement();
			ResultSet rs= st.executeQuery("INSERT into credenziali(username, password) VALUES ('"+username+"', '"+password+"');");
			
			rs.close();
			st.close();
			conn.close();
			
		} catch(SQLException e) {
		}
		
	}
	
	public boolean TrovaCliente(String username) {
		
		boolean trovato = false;
		
		try {
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println("Class not found:\n"+e);
		}
		
		try {
			
			Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/credenzialidb", "postgres", "basididati");
			Statement st = conn.createStatement();
			ResultSet rs= st.executeQuery("SELECT * from credenziali;");
			
			while(rs.next()) {
				if(rs.getString("username").equals(username)==true) {
					trovato = true;
					break;
				} 
			}
			
			rs.close();
			st.close();
			conn.close();
			
			return trovato;
			
		} catch(SQLException e) {
			return trovato;
		}
		
	}
}
