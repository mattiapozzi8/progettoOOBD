package PackageFinestre;
import PackageController.*;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class FinestraCliente extends JFrame {

	private JPanel contentPane;
	public Controller IlController;
	public JLabel Us_JLb = new JLabel();
	public JLabel punti_tessera_lbl = new JLabel("");
	public JLabel punti_frutta_lbl = new JLabel("");
	public JLabel punti_verdura_lbl = new JLabel("");
	public JLabel punti_farinacei_lbl = new JLabel("");
	public JLabel punti_latticini_lbl = new JLabel("");
	public JLabel punti_uova_lbl = new JLabel("");
	public JLabel punti_confezionati_lbl = new JLabel("");

	/**
	 * Create the frame.
	 */
	public FinestraCliente(Controller c) {
		IlController=c;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 316);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		Us_JLb.setFont(new Font("Trebuchet MS", Font.BOLD, 16));
		Us_JLb.setBounds(10, 21, 286, 18);
		contentPane.add(Us_JLb);
		
		JLabel npunti_lbl = new JLabel("Numero punti tessera fedelt\u00E0: ");
		npunti_lbl.setBounds(10, 64, 187, 14);
		contentPane.add(npunti_lbl);
		
		punti_tessera_lbl.setHorizontalAlignment(SwingConstants.LEFT);
		punti_tessera_lbl.setBounds(193, 64, 89, 14);
		contentPane.add(punti_tessera_lbl);
		
		JButton btnNewButton = new JButton("Indietro");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				setVisible(false);
				c.ApriFinestraRicercaCliente();
			}
		});
		btnNewButton.setBounds(335, 243, 89, 23);
		contentPane.add(btnNewButton);
		
		JLabel npuntifrutta_lbl = new JLabel("Punti raccolti Frutta:");
		npuntifrutta_lbl.setBounds(10, 89, 187, 14);
		contentPane.add(npuntifrutta_lbl);
		
		punti_frutta_lbl.setHorizontalAlignment(SwingConstants.LEFT);
		punti_frutta_lbl.setBounds(193, 89, 89, 14);
		contentPane.add(punti_frutta_lbl);
		
		JLabel npuntiverdura_lbl = new JLabel("Punti raccolti Verdura:");
		npuntiverdura_lbl.setBounds(10, 114, 187, 14);
		contentPane.add(npuntiverdura_lbl);
		
		JLabel npuntifarinacei_lbl = new JLabel("Punti raccolti Farinacei:");
		npuntifarinacei_lbl.setBounds(10, 139, 187, 14);
		contentPane.add(npuntifarinacei_lbl);
		
		JLabel npuntilatticini_lbl = new JLabel("Punti raccolti Latticini:");
		npuntilatticini_lbl.setBounds(10, 164, 187, 14);
		contentPane.add(npuntilatticini_lbl);
		
		JLabel npuntiuova_lbl = new JLabel("Punti raccolti Uova:");
		npuntiuova_lbl.setBounds(10, 189, 187, 14);
		contentPane.add(npuntiuova_lbl);
		
		JLabel npunticonfezionati_lbl = new JLabel("Punti raccolti Confezionati:");
		npunticonfezionati_lbl.setBounds(10, 214, 187, 14);
		contentPane.add(npunticonfezionati_lbl);
		
		punti_verdura_lbl.setHorizontalAlignment(SwingConstants.LEFT);
		punti_verdura_lbl.setBounds(193, 114, 89, 14);
		contentPane.add(punti_verdura_lbl);
		
		punti_farinacei_lbl.setHorizontalAlignment(SwingConstants.LEFT);
		punti_farinacei_lbl.setBounds(193, 139, 89, 14);
		contentPane.add(punti_farinacei_lbl);
		
		punti_latticini_lbl.setHorizontalAlignment(SwingConstants.LEFT);
		punti_latticini_lbl.setBounds(193, 164, 89, 14);
		contentPane.add(punti_latticini_lbl);
		
		punti_uova_lbl.setHorizontalAlignment(SwingConstants.LEFT);
		punti_uova_lbl.setBounds(193, 189, 89, 14);
		contentPane.add(punti_uova_lbl);
		
		punti_confezionati_lbl.setHorizontalAlignment(SwingConstants.LEFT);
		punti_confezionati_lbl.setBounds(193, 214, 89, 14);
		contentPane.add(punti_confezionati_lbl);
	}
}
