package PackageFinestre;
import PackageController.*;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.SwingConstants;

public class FinestraCliente extends JFrame {

	private JPanel contentPane;
	public Controller IlController;
	public JLabel Us_JLb = new JLabel();
	public JLabel punti_tessera_lbl = new JLabel();

	/**
	 * Create the frame.
	 */
	public FinestraCliente(Controller c) {
		IlController=c;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 316);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		Us_JLb.setFont(new Font("Trebuchet MS", Font.BOLD, 16));
		Us_JLb.setBounds(10, 21, 286, 18);
		contentPane.add(Us_JLb);
		
		JLabel npunti_lbl = new JLabel("Numero punti tessera fedelt\u00E0: ");
		npunti_lbl.setBounds(10, 64, 147, 14);
		contentPane.add(npunti_lbl);
		
		punti_tessera_lbl = new JLabel("");
		punti_tessera_lbl.setHorizontalAlignment(SwingConstants.RIGHT);
		punti_tessera_lbl.setBounds(160, 64, 89, 14);
		contentPane.add(punti_tessera_lbl);
	}
}
