package PackageFinestre;
import PackageController.*;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import PackageController.Controller;

import javax.swing.JLabel;
import javax.swing.SwingConstants;

public class ErroreCfJDialog extends JDialog {

	private final JPanel contentPanel = new JPanel();

	public Controller IlController;
	
	
	public ErroreCfJDialog(Controller c) {
		IlController=c;
		setAlwaysOnTop(true);
		setModal(true);
		setBounds(100, 100, 439, 156);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JLabel ErroreCf_JLb = new JLabel("Il codice fiscale non \u00E8 valido o non \u00E8 presente nel database");
		ErroreCf_JLb.setHorizontalAlignment(SwingConstants.CENTER);
		ErroreCf_JLb.setBounds(10, 11, 403, 51);
		contentPanel.add(ErroreCf_JLb);
		
		JLabel ErroreVerificaCf_JLb = new JLabel("Verificare di aver inserito un codice di 16 caratteri");
		ErroreVerificaCf_JLb.setHorizontalAlignment(SwingConstants.CENTER);
		ErroreVerificaCf_JLb.setBounds(10, 59, 403, 42);
		contentPanel.add(ErroreVerificaCf_JLb);
	}
}
