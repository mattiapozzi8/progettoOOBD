package PackageFinestre;

import PackageController.*;
import PackageEntit�.Cliente;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JDialog;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class FinestraLogin extends JFrame {

	private JPanel contentPane;
	public JTextField Username_TF;
	public JPasswordField Pwd_TF;
	public Cliente cliente = new Cliente();

	public Controller theController;
	NewDialog2 nd2 = new NewDialog2(theController);
	
	/**
	 * Create the frame.
	 */
	public FinestraLogin(Controller c) {
		theController = c;
		
		setTitle("Login");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		Username_TF = new JTextField();
		Username_TF.setBounds(166, 42, 101, 27);
		contentPane.add(Username_TF);
		Username_TF.setColumns(10);
		
		Pwd_TF = new JPasswordField();
		Pwd_TF.setBounds(166, 99, 101, 27);
		contentPane.add(Pwd_TF);
		
		JLabel lblNewLabel = new JLabel("Username");
		lblNewLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel.setFont(new Font("Calibri", Font.PLAIN, 14));
		lblNewLabel.setBounds(85, 50, 71, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Password");
		lblNewLabel_1.setFont(new Font("Calibri", Font.PLAIN, 14));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1.setBounds(85, 107, 71, 14);
		contentPane.add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("Avanti");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				if(Username_TF.getText().length()>0 && Pwd_TF.getText().length()>0) {
					theController.ControlloCredenziali(Username_TF.getText(), Pwd_TF.getText());
				//	cliente.setUsername(Username_TF.getText());
				//	cliente.setPassword(Pwd_TF.getText());
				//	theController.ControlloCredenziali();
				}
				else {
					nd2.setVisible(true);
				}
					
				
			}
		});
		btnNewButton.setFont(new Font("Calibri", Font.PLAIN, 14));
		btnNewButton.setBounds(305, 207, 119, 43);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Registrati qui!");
		btnNewButton_1.setFont(new Font("Calibri", Font.PLAIN, 14));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				theController.LoginWindow.setVisible(false);
				theController.RegistrazioneWindow.setVisible(true);
				
			}
		});
		btnNewButton_1.setBounds(10, 207, 119, 43);
		contentPane.add(btnNewButton_1);
		
		JLabel lblNewLabel_2 = new JLabel("Sei nuovo?");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_2.setBounds(10, 187, 119, 14);
		contentPane.add(lblNewLabel_2);
	}
	
		public void SvuotaCampi() {
			
			Username_TF.setText(null);
			Pwd_TF.setText(null);
		}
}
