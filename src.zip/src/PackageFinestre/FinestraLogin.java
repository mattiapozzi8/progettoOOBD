package PackageFinestre;

import PackageController.*;
import PackageEntit�.Cliente;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JDialog;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class FinestraLogin extends JFrame {

	private JPanel contentPane;
	public JTextField Username_TF;
	public JPasswordField Pwd_TF;
	public Controller theController;
	NewDialog2 nd2 = new NewDialog2(theController);
	
	/**
	 * Create the frame.
	 */
	public FinestraLogin(Controller c) {
		theController = c;
		
		setTitle("Login");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		Username_TF = new JTextField();
		Username_TF.setBounds(166, 42, 101, 27);
		contentPane.add(Username_TF);
		Username_TF.setColumns(10);
		
		Pwd_TF = new JPasswordField();
		Pwd_TF.setBounds(166, 99, 101, 27);
		contentPane.add(Pwd_TF);
		
		JLabel user_lbl = new JLabel("Username");
		user_lbl.setHorizontalAlignment(SwingConstants.RIGHT);
		user_lbl.setFont(new Font("Calibri", Font.PLAIN, 14));
		user_lbl.setBounds(85, 50, 71, 14);
		contentPane.add(user_lbl);
		
		JLabel pass_lbl = new JLabel("Password");
		pass_lbl.setFont(new Font("Calibri", Font.PLAIN, 14));
		pass_lbl.setHorizontalAlignment(SwingConstants.RIGHT);
		pass_lbl.setBounds(85, 107, 71, 14);
		contentPane.add(pass_lbl);
		
		JButton AvantiButton = new JButton("Avanti");
		AvantiButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				if(Username_TF.getText().length()>0 && Pwd_TF.getText().length()>0) {
					theController.ControlloCredenziali(Username_TF.getText(), Pwd_TF.getText());
				}
				else {
					nd2.setVisible(true);
				}
					
				
			}
		});
		AvantiButton.setFont(new Font("Calibri", Font.PLAIN, 14));
		AvantiButton.setBounds(305, 207, 119, 43);
		contentPane.add(AvantiButton);
		
		JButton registratiButton = new JButton("Registrati qui!");
		registratiButton.setFont(new Font("Calibri", Font.PLAIN, 14));
		registratiButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				theController.RegistrazioneWindow.setVisible(true);
				
			}
		});
		registratiButton.setBounds(10, 207, 119, 43);
		contentPane.add(registratiButton);
		
		JLabel nuovo_lbl = new JLabel("Sei nuovo?");
		nuovo_lbl.setHorizontalAlignment(SwingConstants.CENTER);
		nuovo_lbl.setFont(new Font("Tahoma", Font.PLAIN, 12));
		nuovo_lbl.setBounds(10, 187, 119, 14);
		contentPane.add(nuovo_lbl);
		
		JButton IndietroButton = new JButton("Indietro");
		IndietroButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				setVisible(false);
			}
		});
		IndietroButton.setBounds(335, 11, 89, 23);
		contentPane.add(IndietroButton);
	}
	
		public void SvuotaCampi() {
			
			Username_TF.setText(null);
			Pwd_TF.setText(null);
		}
}
