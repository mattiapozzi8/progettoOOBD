package PackageFinestre;
import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JToggleButton;

import PackageController.Controller;
public class FinestraLatticini extends JFrame {

	private JPanel contentPane;
	public JTextField Quantit�_TF;
	public Controller IlController;
	private double Quantit�DaSottrarreDouble;
	private JTextField PrezzoAlKilo_TF;
	private JTextField DispInMagazzino_TF;
	private double PrezzoAlKiloDouble;
	private JTextField SimboloEuro;
	private String DispInMagazzinoString;
	private JTextField SelezionaLatticini_TF;
	private String TipoLatticini;
	private String CopiaTipoLatticini;
	public int disp_tot = 0;
	public 	JButton PiuButton=new JButton("+");

	public String getCopiaTipoLatticini() {
		return CopiaTipoLatticini;
	}
	public void setCopiaTipoLatticini(String tipoLatticini) {
		CopiaTipoLatticini = tipoLatticini;
	}
	public String getDispInMagazzinoString() {
		return DispInMagazzinoString;
	}
	public void setDispInMagazzinoString(String dispInMagazzinoString) {
		DispInMagazzinoString = dispInMagazzinoString;
	}
	public void setQuantit�DaSottrarreDouble(double quantit�DaSottrarreDouble) {
		Quantit�DaSottrarreDouble = 0.0;
	}
	public double getQuantit�DaSottrarreDouble() {
		return Quantit�DaSottrarreDouble;
	}
	
	public double getPrezzoAlKiloDouble() {
		return PrezzoAlKiloDouble;
	}
	


	/**
	 * Create the frame.
	 */
	public FinestraLatticini(Controller c) {
		setTitle("Latticini");
		
		IlController=c;
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 498, 339);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel Latticini_JLb = new JLabel("Latticini");
		Latticini_JLb.setHorizontalAlignment(SwingConstants.CENTER);
		Latticini_JLb.setFont(new Font("Arial Black", Font.PLAIN, 20));
		Latticini_JLb.setBounds(186, 0, 109, 25);
		contentPane.add(Latticini_JLb);
		
		JLabel Quantit�_JLb = new JLabel("Quantit\u00E0 (in chili) che desidera aquistare:");
		Quantit�_JLb.setFont(new Font("Cambria", Font.PLAIN, 14));
		Quantit�_JLb.setBounds(10, 145, 261, 16);
		contentPane.add(Quantit�_JLb);
		
		Quantit�_TF = new JTextField();
		Quantit�_TF.setEditable(false);
		Quantit�_TF.setText("0");
		Quantit�_TF.setFont(new Font("Cambria", Font.PLAIN, 13));
		Quantit�_TF.setHorizontalAlignment(SwingConstants.CENTER);
		Quantit�_TF.setToolTipText("Inserire quantit\u00E0 desiderata");
		Quantit�_TF.setBounds(321, 144, 78, 20);
		contentPane.add(Quantit�_TF);
		Quantit�_TF.setColumns(10);
		
		JButton AvantiButton = new JButton("Avanti");
		AvantiButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if((Double.valueOf(Quantit�_TF.getText()))<=(Double.valueOf(DispInMagazzino_TF.getText()))) {
					if(Double.valueOf(Quantit�_TF.getText())!=0) {
					Quantit�_TF.setEditable(false);
					c.prod.setQuantit�(Double.valueOf(Quantit�_TF.getText()));
					setVisible(false);
					IlController.InfoProdotto();
					IlController.ConfermaProdottoWindow.setVisible(true);
						}
					} else {
						c.aqm_dialog.setVisible(true);
					}

				
			}
		});
		AvantiButton.setBounds(318, 265, 154, 23);
		contentPane.add(AvantiButton);
		
		JLabel PrezzoAlKilo_JLb = new JLabel(" Prezzo al Chilo:");
		PrezzoAlKilo_JLb.setFont(new Font("Cambria", Font.PLAIN, 15));
		PrezzoAlKilo_JLb.setBounds(9, 110, 109, 14);
		contentPane.add(PrezzoAlKilo_JLb);
		
		PrezzoAlKilo_TF = new JTextField();
		PrezzoAlKilo_TF.setFont(new Font("Cambria", Font.PLAIN, 13));
		PrezzoAlKilo_TF.setHorizontalAlignment(SwingConstants.CENTER);
		PrezzoAlKilo_TF.setEditable(false);
		PrezzoAlKilo_TF.setBounds(114, 108, 35, 20);
		contentPane.add(PrezzoAlKilo_TF);
		PrezzoAlKilo_TF.setColumns(10);
		
		JLabel DispInMagazzino_JLb = new JLabel("Disponibilit\u00E0 in magazzino:");
		DispInMagazzino_JLb.setFont(new Font("Cambria", Font.PLAIN, 15));
		DispInMagazzino_JLb.setBounds(10, 71, 176, 25);
		contentPane.add(DispInMagazzino_JLb);
		
		DispInMagazzino_TF = new JTextField();
		DispInMagazzino_TF.setFont(new Font("Cambria", Font.PLAIN, 14));
		DispInMagazzino_TF.setHorizontalAlignment(SwingConstants.LEFT);
		DispInMagazzino_TF.setEditable(false);
		DispInMagazzino_TF.setBounds(187, 74, 262, 20);
		contentPane.add(DispInMagazzino_TF);
		DispInMagazzino_TF.setColumns(10);
		

		JButton TornaHomeButton = new JButton("Torna alla home");
		TornaHomeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c.TornaAllaHome();
			}
		});
		TornaHomeButton.setBounds(10, 265, 154, 23);
		contentPane.add(TornaHomeButton);
		
		SimboloEuro = new JTextField();
		SimboloEuro.setEditable(false);
		SimboloEuro.setFont(new Font("Cambria", Font.PLAIN, 13));
		SimboloEuro.setHorizontalAlignment(SwingConstants.CENTER);
		SimboloEuro.setText("\u20AC");
		SimboloEuro.setBounds(148, 108, 18, 20);
		contentPane.add(SimboloEuro);
		SimboloEuro.setColumns(10);
		
		JComboBox LatticiniComboBox = new JComboBox();
		
		LatticiniComboBox.setModel(new DefaultComboBoxModel(new String[] {"Latte", "Burro", "Mozzarella", "Yogurt", "Formaggio", "Panna", "Ricotta"}));
		LatticiniComboBox.setToolTipText("");
		LatticiniComboBox.setSelectedItem(null);
		LatticiniComboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				TipoLatticini = (String) LatticiniComboBox.getSelectedItem();
				
				
				if(TipoLatticini.equals("Latte")) {
					IlController.prod = IlController.ConnettiAlDB("Latte");
					PrezzoAlKilo_TF.setText(String.valueOf(IlController.ConnettiAlDB("Latte").getPrezzoAlKilo()));
					disp_tot = IlController.ConnettiAlDB("Latte").getDisponibilit�();
					DispInMagazzino_TF.setText(String.valueOf(disp_tot));

				}
				
				if(TipoLatticini.equals("Burro")) {
					IlController.prod = IlController.ConnettiAlDB("Burro");
					PrezzoAlKilo_TF.setText(String.valueOf(IlController.ConnettiAlDB("Burro").getPrezzoAlKilo()));
					disp_tot = IlController.ConnettiAlDB("Burro").getDisponibilit�();
					DispInMagazzino_TF.setText(String.valueOf(disp_tot));
				}
				
				if(TipoLatticini.equals("Mozzarella")) {
					IlController.prod = IlController.ConnettiAlDB("Mozzarella");
					PrezzoAlKilo_TF.setText(String.valueOf(IlController.ConnettiAlDB("Mozzarella").getPrezzoAlKilo()));
					disp_tot = IlController.ConnettiAlDB("Mozzarella").getDisponibilit�();
					DispInMagazzino_TF.setText(String.valueOf(disp_tot));
				}

				if(TipoLatticini.equals("Yogurt")) {
					IlController.prod = IlController.ConnettiAlDB("Yogurt");
					PrezzoAlKilo_TF.setText(String.valueOf(IlController.ConnettiAlDB("Yogurt").getPrezzoAlKilo()));
					disp_tot = IlController.ConnettiAlDB("Yogurt").getDisponibilit�();
					DispInMagazzino_TF.setText(String.valueOf(disp_tot));
				}
				
				if(TipoLatticini.equals("Formaggio")) {
					IlController.prod = IlController.ConnettiAlDB("Formaggio");
					PrezzoAlKilo_TF.setText(String.valueOf(IlController.ConnettiAlDB("Formaggio").getPrezzoAlKilo()));
					disp_tot = IlController.ConnettiAlDB("Formaggio").getDisponibilit�();
					DispInMagazzino_TF.setText(String.valueOf(disp_tot));
				}
				
				if(TipoLatticini.equals("Panna")) {
					IlController.prod = IlController.ConnettiAlDB("Panna");
					PrezzoAlKilo_TF.setText(String.valueOf(IlController.ConnettiAlDB("Panna").getPrezzoAlKilo()));
					disp_tot = IlController.ConnettiAlDB("Panna").getDisponibilit�();
					DispInMagazzino_TF.setText(String.valueOf(disp_tot));
				}
				
				if(TipoLatticini.equals("Ricotta")) {
					IlController.prod = IlController.ConnettiAlDB("Ricotta");
					PrezzoAlKilo_TF.setText(String.valueOf(IlController.ConnettiAlDB("Ricotta").getPrezzoAlKilo()));
					disp_tot = IlController.ConnettiAlDB("Ricotta").getDisponibilit�();
					DispInMagazzino_TF.setText(String.valueOf(disp_tot));
				}
				
			}
		});
		
		
		LatticiniComboBox.setBounds(141, 36, 109, 24);
		contentPane.add(LatticiniComboBox);
		
		SelezionaLatticini_TF = new JTextField();
		SelezionaLatticini_TF.setEditable(false);
		SelezionaLatticini_TF.setFont(new Font("Cambria", Font.PLAIN, 14));
		SelezionaLatticini_TF.setText("Seleziona Latticini:");
		SelezionaLatticini_TF.setBounds(10, 36, 126, 25);
		contentPane.add(SelezionaLatticini_TF);
		SelezionaLatticini_TF.setColumns(10);
		
		JButton PiuButton = new JButton("+");
		PiuButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int tmp = Integer.parseInt(Quantit�_TF.getText());
				Quantit�_TF.setText(String.valueOf(tmp+1));		
			}
		});
		PiuButton.setBounds(400, 144, 49, 20);
		contentPane.add(PiuButton);
		
		JButton MenoButton = new JButton("-");
		MenoButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int tmp = Integer.parseInt(Quantit�_TF.getText());
				if(Integer.parseInt(Quantit�_TF.getText())>0) {
				Quantit�_TF.setText(String.valueOf(tmp-1));
				}
			}
		});
		MenoButton.setBounds(270, 144, 49, 20);
		contentPane.add(MenoButton);
		
	}
	
}
