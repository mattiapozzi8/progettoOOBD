package PackageFinestre;
import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JToggleButton;

import PackageController.Controller;
public class FinestraLatticini extends JFrame {

	private JPanel contentPane;
	private JTextField Quantit�_TF;
	public Controller IlController;
	private double Quantit�DaSottrarreDouble;
	private JTextField PrezzoAlKilo_TF;
	private JTextField DispInMagazzino_TF;
	private double PrezzoAlKiloDouble;
	private JTextField SimboloEuro;
	private String DispInMagazzinoString;
	private JTextField SelezionaLatticini_TF;
	public String TipoVerdura=null;
	
	
	public String getDispInMagazzinoString() {
		return DispInMagazzinoString;
	}
	public void setDispInMagazzinoString(String dispInMagazzinoString) {
		DispInMagazzinoString = dispInMagazzinoString;
	}
	public void setQuantit�DaSottrarreDouble(double quantit�DaSottrarreDouble) {
		Quantit�DaSottrarreDouble = 0.0;
	}
	public double getQuantit�DaSottrarreDouble() {
		return Quantit�DaSottrarreDouble;
	}
	
	public double getPrezzoAlKiloDouble() {
		return PrezzoAlKiloDouble;
	}
	


	/**
	 * Create the frame.
	 */
	public FinestraLatticini(Controller c) {
		
		IlController=c;
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 498, 339);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel Latticini_JLb = new JLabel("Latticini");
		Latticini_JLb.setHorizontalAlignment(SwingConstants.CENTER);
		Latticini_JLb.setFont(new Font("Cambria", Font.PLAIN, 20));
		Latticini_JLb.setBounds(187, 0, 109, 25);
		contentPane.add(Latticini_JLb);
		
		JLabel Quantit�_JLb = new JLabel("Quantit\u00E0(in litri/chili) che desidera aquistare:");
		Quantit�_JLb.setFont(new Font("Cambria", Font.PLAIN, 14));
		Quantit�_JLb.setBounds(10, 144, 297, 16);
		contentPane.add(Quantit�_JLb);
		
		JButton AvantiButton = new JButton("Avanti");
		AvantiButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Quantit�DaSottrarreString=Quantit�_TF.getText();
				try {
					Quantit�DaSottrarreDouble = Double.parseDouble(Quantit�DaSottrarreString);	
				}
				catch (NumberFormatException Nfe){
					System.err.println("");
				}
				DispInMagazzinoString=c.SottraiQuantit�();
				DispInMagazzino_TF.setText(DispInMagazzinoString);
				if((DispInMagazzinoString.equals("Non ci sono abbastanza scorte"))){
					Quantit�_TF.setEditable(false);
				}
					else {
						DispInMagazzino_TF.setText(DispInMagazzinoString);
						AvantiButton.setEnabled(false);
						Quantit�_TF.setEditable(false);
						setVisible(false);
						IlController.ConfermaProdottoWindow.setVisible(true);
					}
				
			}
		});
		AvantiButton.setBounds(318, 265, 154, 23);
		contentPane.add(AvantiButton);
		
		Quantit�_TF = new JTextField();
		Quantit�_TF.setText("0");
		Quantit�_TF.setEditable(false);
		Quantit�_TF.setFont(new Font("Cambria", Font.PLAIN, 13));
		Quantit�_TF.setHorizontalAlignment(SwingConstants.CENTER);
		Quantit�_TF.setToolTipText("Inserire quantit\u00E0 desiderata");
		Quantit�_TF.setBounds(348, 144, 70, 20);
		contentPane.add(Quantit�_TF);
		Quantit�_TF.setColumns(10);
		
		JLabel PrezzoAlKilo_JLb = new JLabel("Prezzo al Chilo/Litro:");
		PrezzoAlKilo_JLb.setFont(new Font("Cambria", Font.PLAIN, 15));
		PrezzoAlKilo_JLb.setBounds(10, 110, 147, 14);
		contentPane.add(PrezzoAlKilo_JLb);
		
		PrezzoAlKilo_TF = new JTextField();
		PrezzoAlKilo_TF.setFont(new Font("Cambria", Font.PLAIN, 13));
		PrezzoAlKilo_TF.setHorizontalAlignment(SwingConstants.CENTER);
		PrezzoAlKilo_TF.setEditable(false);
		PrezzoAlKilo_TF.setBounds(147, 108, 35, 20);
		contentPane.add(PrezzoAlKilo_TF);
		PrezzoAlKilo_TF.setColumns(10);
		
		JLabel DispInMagazzino_JLb = new JLabel("Disponibilit\u00E0 in magazzino:");
		DispInMagazzino_JLb.setFont(new Font("Cambria", Font.PLAIN, 15));
		DispInMagazzino_JLb.setBounds(10, 71, 176, 25);
		contentPane.add(DispInMagazzino_JLb);
		
		DispInMagazzino_TF = new JTextField();
		DispInMagazzino_TF.setFont(new Font("Cambria", Font.PLAIN, 14));
		DispInMagazzino_TF.setHorizontalAlignment(SwingConstants.LEFT);
		DispInMagazzino_TF.setEditable(false);
		DispInMagazzino_TF.setBounds(187, 74, 262, 20);
		contentPane.add(DispInMagazzino_TF);
		DispInMagazzino_TF.setColumns(10);
		

		JButton TornaHomeButton = new JButton("Torna alla home");
		TornaHomeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c.TornaAllaHome();
			}
		});
		TornaHomeButton.setBounds(10, 265, 154, 23);
		contentPane.add(TornaHomeButton);
		
		SimboloEuro = new JTextField();
		SimboloEuro.setEditable(false);
		SimboloEuro.setFont(new Font("Cambria", Font.PLAIN, 13));
		SimboloEuro.setHorizontalAlignment(SwingConstants.CENTER);
		SimboloEuro.setText("\u20AC");
		SimboloEuro.setBounds(181, 108, 18, 20);
		contentPane.add(SimboloEuro);
		SimboloEuro.setColumns(10);
		
		JComboBox LatticiniComboBox = new JComboBox();
		
		LatticiniComboBox.setModel(new DefaultComboBoxModel(new String[] {"Latte", "Burro", "Mozzarella", "Yogurt", "Formaggio", "Panna", "Ricotta"}));
		LatticiniComboBox.setToolTipText("");
		LatticiniComboBox.setSelectedItem(null);
		LatticiniComboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				TipoVerdura = (String) LatticiniComboBox.getSelectedItem();
				
				if(TipoVerdura.equals("Latte")) {
					PrezzoAlKilo_TF.setText("1.82");
					Quantit�_TF.setEditable(true);
				}
				
				if(TipoVerdura.equals("Burro")) {
					PrezzoAlKilo_TF.setText("2.92");
					Quantit�_TF.setEditable(true);
				}
				
				if(TipoVerdura.equals("Mozzarella")) {
					PrezzoAlKilo_TF.setText("2.02");
					Quantit�_TF.setEditable(true);
				}

				if(TipoVerdura.equals("Yogurt")) {
					PrezzoAlKilo_TF.setText("2.47");
					Quantit�_TF.setEditable(true);
				}
				
				if(TipoVerdura.equals("Formaggio")) {
					PrezzoAlKilo_TF.setText("3.27");
					Quantit�_TF.setEditable(true);
				}
				
				if(TipoVerdura.equals("Panna")) {
					PrezzoAlKilo_TF.setText("3.10");
					Quantit�_TF.setEditable(true);
				}
				
				if(TipoVerdura.equals("Ricotta")) {
					PrezzoAlKilo_TF.setText("2.17");
					Quantit�_TF.setEditable(true);
				}
				
			}
		});
		LatticiniComboBox.setBounds(145, 36, 109, 24);
		contentPane.add(LatticiniComboBox);
		
		SelezionaLatticini_TF = new JTextField();
		SelezionaLatticini_TF.setEditable(false);
		SelezionaLatticini_TF.setFont(new Font("Cambria", Font.PLAIN, 14));
		SelezionaLatticini_TF.setText("Seleziona Latticini:");
		SelezionaLatticini_TF.setBounds(10, 36, 132, 25);
		contentPane.add(SelezionaLatticini_TF);
		SelezionaLatticini_TF.setColumns(10);
		
		
		JButton PiuButton = new JButton("+");
		PiuButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int tmp = Integer.parseInt(Quantit�_TF.getText());
				Quantit�_TF.setText(String.valueOf(tmp+1));
			}
		});
		PiuButton.setBounds(423, 144, 49, 20);
		contentPane.add(PiuButton);
		
		JButton MenoButton = new JButton("-");
		MenoButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int tmp = Integer.parseInt(Quantit�_TF.getText());
				if(Integer.parseInt(Quantit�_TF.getText())>0) {
				Quantit�_TF.setText(String.valueOf(tmp-1));
				}
			}
		});
		MenoButton.setBounds(293, 144, 49, 20);
		contentPane.add(MenoButton);
	}
	
}