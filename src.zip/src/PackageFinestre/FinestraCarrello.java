package PackageFinestre;
import PackageController.*;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class FinestraCarrello extends JFrame {

	private JPanel contentPane;
	public Controller IlController;
	public JLabel ProdottiInCarrello_lbl;
	private JButton TornaAllaHP;
	public int i;

	/**
	 * Create the frame.
	 */
	public FinestraCarrello(Controller c) {
		IlController=c;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 437, 509);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Carrello");
		lblNewLabel.setFont(new Font("Cambria", Font.PLAIN, 20));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(10, 11, 401, 27);
		contentPane.add(lblNewLabel);
		
		ProdottiInCarrello_lbl = new JLabel("");
		ProdottiInCarrello_lbl.setVerticalAlignment(SwingConstants.TOP);
		ProdottiInCarrello_lbl.setHorizontalAlignment(SwingConstants.LEFT);
		ProdottiInCarrello_lbl.setBounds(10, 69, 401, 247);
		contentPane.add(ProdottiInCarrello_lbl);
		
		TornaAllaHP = new JButton("Torna Alla Home");
		TornaAllaHP.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				IlController.TornaAllaHome();
			}
		});
		TornaAllaHP.setBounds(0, 448, 143, 23);
		contentPane.add(TornaAllaHP);
		
		JLabel NomeProdInCarrello_lbl = new JLabel("");
		NomeProdInCarrello_lbl.setBounds(10, 69, 67, 14);
		contentPane.add(NomeProdInCarrello_lbl);
		
		JLabel Quantit�ProdInCarrello_lbl = new JLabel("Quantit\u00E0:");
		Quantit�ProdInCarrello_lbl.setBounds(132, 44, 60, 14);
		contentPane.add(Quantit�ProdInCarrello_lbl);
		
		JLabel PrezzoTotCarrello_lbl = new JLabel("Prezzo totale:");
		PrezzoTotCarrello_lbl.setBounds(324, 44, 87, 14);
		contentPane.add(PrezzoTotCarrello_lbl);
	}
}
