package PackageFinestre;
import PackageController.*;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class FinestraCarrello extends JFrame {

	private JPanel contentPane;
	public Controller IlController;
	public JLabel ProdottiInCarrello_lbl;
	public JLabel ProdottiInCarrello2_lbl;
	public JLabel ProdottiInCarrello3_lbl;
	public JLabel ProdottiInCarrello4_lbl;
	public JLabel ProdottiInCarrello5_lbl;
	public JLabel ProdottiInCarrello6_lbl;
	public JLabel ProdottiInCarrello7_lbl;
	public JLabel ProdottiInCarrello8_lbl;
	public JLabel ProdottiInCarrello9_lbl;
	public JLabel ProdottiInCarrello10_lbl;
	public JLabel ProdottiInCarrello11_lbl;
	public JLabel ProdottiInCarrello12_lbl;
	public JLabel ProdottiInCarrello13_lbl;
	public JLabel ProdottiInCarrello14_lbl;
	public JLabel ProdottiInCarrello15_lbl;
	public JLabel Quantit�_lbl;
	public JLabel Quantit�_lbl_1;
	public JLabel Quantit�_lbl_2;
	public JLabel Quantit�_lbl_3;
	public JLabel Quantit�_lbl_4;
	public JLabel Quantit�_lbl_5;
	public JLabel Quantit�_lbl_6;
	public JLabel Quantit�_lbl_7;
	public JLabel Quantit�_lbl_8;
	public JLabel Quantit�_lbl_9;
	public JLabel Quantit�_lbl_10;
	public JLabel Quantit�_lbl_11;
	public JLabel Quantit�_lbl_12;
	public JLabel Quantit�_lbl_13;
	public JLabel Quantit�_lbl_14;
	private JButton TornaAllaHP;
	public JLabel Prezzo_lbl;
	public JLabel Prezzo_lbl_1;
	public JLabel Prezzo_lbl_2;
	public JLabel Prezzo_lbl_3;
	public JLabel Prezzo_lbl_4;
	public JLabel Prezzo_lbl_5;
	public JLabel Prezzo_lbl_6;
	public JLabel Prezzo_lbl_7;
	public JLabel Prezzo_lbl_8;
	public JLabel Prezzo_lbl_9;
	public JLabel Prezzo_lbl_10;
	public JLabel Prezzo_lbl_11;
	public JLabel Prezzo_lbl_12;
	public JLabel Prezzo_lbl_13;
	public JLabel Prezzo_lbl_14;
	public JLabel Prezzo_tot_lbl;
	public double prezzo_tot=0;
	private JButton SvuotaCarrelloButton;

	/**
	 * Create the frame.
	 */
	public FinestraCarrello(Controller c) {
		setTitle("Carrello");
		IlController=c;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 437, 509);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel CarrelloLabel = new JLabel("Carrello");
		CarrelloLabel.setFont(new Font("Arial Black", Font.PLAIN, 20));
		CarrelloLabel.setHorizontalAlignment(SwingConstants.CENTER);
		CarrelloLabel.setBounds(10, 11, 401, 27);
		contentPane.add(CarrelloLabel);
		
		ProdottiInCarrello_lbl = new JLabel("");
		ProdottiInCarrello_lbl.setFont(new Font("Tahoma", Font.PLAIN, 13));
		ProdottiInCarrello_lbl.setVerticalAlignment(SwingConstants.TOP);
		ProdottiInCarrello_lbl.setHorizontalAlignment(SwingConstants.LEFT);
		ProdottiInCarrello_lbl.setBounds(10, 70, 111, 20);
		contentPane.add(ProdottiInCarrello_lbl);
		
		TornaAllaHP = new JButton("Torna Alla Home");
		TornaAllaHP.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				IlController.TornaAllaHome();
			}
		});
		TornaAllaHP.setBounds(10, 436, 133, 23);
		contentPane.add(TornaAllaHP);
		
		JLabel NomeProdInCarrello_lbl = new JLabel("Prodotto:");
		NomeProdInCarrello_lbl.setBounds(10, 44, 67, 14);
		contentPane.add(NomeProdInCarrello_lbl);
		
		JLabel Quantit�ProdInCarrello_lbl = new JLabel("Quantit\u00E0:");
		Quantit�ProdInCarrello_lbl.setBounds(132, 44, 60, 14);
		contentPane.add(Quantit�ProdInCarrello_lbl);
		
		JLabel PrezzoTotCarrello_lbl = new JLabel("Prezzo totale:");
		PrezzoTotCarrello_lbl.setBounds(324, 44, 87, 14);
		contentPane.add(PrezzoTotCarrello_lbl);
		
		ProdottiInCarrello2_lbl = new JLabel("");
		ProdottiInCarrello2_lbl.setFont(new Font("Tahoma", Font.PLAIN, 13));
		ProdottiInCarrello2_lbl.setBounds(10, 92, 111, 20);
		contentPane.add(ProdottiInCarrello2_lbl);
		
		ProdottiInCarrello3_lbl = new JLabel("");
		ProdottiInCarrello3_lbl.setFont(new Font("Tahoma", Font.PLAIN, 13));
		ProdottiInCarrello3_lbl.setBounds(10, 114, 111, 20);
		contentPane.add(ProdottiInCarrello3_lbl);
		
		ProdottiInCarrello4_lbl = new JLabel("");
		ProdottiInCarrello4_lbl.setFont(new Font("Tahoma", Font.PLAIN, 13));
		ProdottiInCarrello4_lbl.setBounds(10, 136, 111, 20);
		contentPane.add(ProdottiInCarrello4_lbl);
		
		ProdottiInCarrello5_lbl = new JLabel("");
		ProdottiInCarrello5_lbl.setFont(new Font("Tahoma", Font.PLAIN, 13));
		ProdottiInCarrello5_lbl.setBounds(10, 158, 111, 20);
		contentPane.add(ProdottiInCarrello5_lbl);
		
		ProdottiInCarrello6_lbl = new JLabel("");
		ProdottiInCarrello6_lbl.setFont(new Font("Tahoma", Font.PLAIN, 13));
		ProdottiInCarrello6_lbl.setBounds(10, 180, 111, 20);
		contentPane.add(ProdottiInCarrello6_lbl);
		
		ProdottiInCarrello7_lbl = new JLabel("");
		ProdottiInCarrello7_lbl.setFont(new Font("Tahoma", Font.PLAIN, 13));
		ProdottiInCarrello7_lbl.setBounds(10, 202, 111, 20);
		contentPane.add(ProdottiInCarrello7_lbl);
		
		ProdottiInCarrello8_lbl = new JLabel("");
		ProdottiInCarrello8_lbl.setFont(new Font("Tahoma", Font.PLAIN, 13));
		ProdottiInCarrello8_lbl.setBounds(10, 224, 111, 20);
		contentPane.add(ProdottiInCarrello8_lbl);
		
		ProdottiInCarrello9_lbl = new JLabel("");
		ProdottiInCarrello9_lbl.setFont(new Font("Tahoma", Font.PLAIN, 13));
		ProdottiInCarrello9_lbl.setBounds(10, 246, 111, 20);
		contentPane.add(ProdottiInCarrello9_lbl);
		
		ProdottiInCarrello10_lbl = new JLabel("");
		ProdottiInCarrello10_lbl.setFont(new Font("Tahoma", Font.PLAIN, 13));
		ProdottiInCarrello10_lbl.setBounds(10, 268, 111, 20);
		contentPane.add(ProdottiInCarrello10_lbl);
		
		ProdottiInCarrello11_lbl = new JLabel("");
		ProdottiInCarrello11_lbl.setFont(new Font("Tahoma", Font.PLAIN, 13));
		ProdottiInCarrello11_lbl.setBounds(10, 290, 111, 20);
		contentPane.add(ProdottiInCarrello11_lbl);
		
		ProdottiInCarrello12_lbl = new JLabel("");
		ProdottiInCarrello12_lbl.setFont(new Font("Tahoma", Font.PLAIN, 13));
		ProdottiInCarrello12_lbl.setBounds(10, 312, 111, 20);
		contentPane.add(ProdottiInCarrello12_lbl);
		
		ProdottiInCarrello13_lbl = new JLabel("");
		ProdottiInCarrello13_lbl.setFont(new Font("Tahoma", Font.PLAIN, 13));
		ProdottiInCarrello13_lbl.setBounds(10, 334, 111, 20);
		contentPane.add(ProdottiInCarrello13_lbl);
		
		ProdottiInCarrello14_lbl = new JLabel("");
		ProdottiInCarrello14_lbl.setFont(new Font("Tahoma", Font.PLAIN, 13));
		ProdottiInCarrello14_lbl.setBounds(10, 356, 111, 20);
		contentPane.add(ProdottiInCarrello14_lbl);
		
		ProdottiInCarrello15_lbl = new JLabel("");
		ProdottiInCarrello15_lbl.setFont(new Font("Tahoma", Font.PLAIN, 13));
		ProdottiInCarrello15_lbl.setBounds(10, 378, 111, 20);
		contentPane.add(ProdottiInCarrello15_lbl);
		
		Quantit�_lbl = new JLabel("");
		Quantit�_lbl.setVerticalAlignment(SwingConstants.TOP);
		Quantit�_lbl.setHorizontalAlignment(SwingConstants.LEFT);
		Quantit�_lbl.setFont(new Font("Tahoma", Font.PLAIN, 13));
		Quantit�_lbl.setBounds(131, 70, 111, 20);
		contentPane.add(Quantit�_lbl);
		
		Quantit�_lbl_1 = new JLabel("");
		Quantit�_lbl_1.setVerticalAlignment(SwingConstants.TOP);
		Quantit�_lbl_1.setHorizontalAlignment(SwingConstants.LEFT);
		Quantit�_lbl_1.setFont(new Font("Tahoma", Font.PLAIN, 13));
		Quantit�_lbl_1.setBounds(132, 92, 111, 20);
		contentPane.add(Quantit�_lbl_1);
		
		Quantit�_lbl_2 = new JLabel("");
		Quantit�_lbl_2.setVerticalAlignment(SwingConstants.TOP);
		Quantit�_lbl_2.setHorizontalAlignment(SwingConstants.LEFT);
		Quantit�_lbl_2.setFont(new Font("Tahoma", Font.PLAIN, 13));
		Quantit�_lbl_2.setBounds(132, 114, 111, 20);
		contentPane.add(Quantit�_lbl_2);
		
		Quantit�_lbl_3 = new JLabel("");
		Quantit�_lbl_3.setVerticalAlignment(SwingConstants.TOP);
		Quantit�_lbl_3.setHorizontalAlignment(SwingConstants.LEFT);
		Quantit�_lbl_3.setFont(new Font("Tahoma", Font.PLAIN, 13));
		Quantit�_lbl_3.setBounds(132, 136, 111, 20);
		contentPane.add(Quantit�_lbl_3);
		
		Quantit�_lbl_4 = new JLabel("");
		Quantit�_lbl_4.setVerticalAlignment(SwingConstants.TOP);
		Quantit�_lbl_4.setHorizontalAlignment(SwingConstants.LEFT);
		Quantit�_lbl_4.setFont(new Font("Tahoma", Font.PLAIN, 13));
		Quantit�_lbl_4.setBounds(132, 158, 111, 20);
		contentPane.add(Quantit�_lbl_4);
		
		Quantit�_lbl_5 = new JLabel("");
		Quantit�_lbl_5.setVerticalAlignment(SwingConstants.TOP);
		Quantit�_lbl_5.setHorizontalAlignment(SwingConstants.LEFT);
		Quantit�_lbl_5.setFont(new Font("Tahoma", Font.PLAIN, 13));
		Quantit�_lbl_5.setBounds(132, 180, 111, 20);
		contentPane.add(Quantit�_lbl_5);
		
		Quantit�_lbl_6 = new JLabel("");
		Quantit�_lbl_6.setVerticalAlignment(SwingConstants.TOP);
		Quantit�_lbl_6.setHorizontalAlignment(SwingConstants.LEFT);
		Quantit�_lbl_6.setFont(new Font("Tahoma", Font.PLAIN, 13));
		Quantit�_lbl_6.setBounds(132, 202, 111, 20);
		contentPane.add(Quantit�_lbl_6);
		
		Quantit�_lbl_7 = new JLabel("");
		Quantit�_lbl_7.setVerticalAlignment(SwingConstants.TOP);
		Quantit�_lbl_7.setHorizontalAlignment(SwingConstants.LEFT);
		Quantit�_lbl_7.setFont(new Font("Tahoma", Font.PLAIN, 13));
		Quantit�_lbl_7.setBounds(132, 224, 111, 20);
		contentPane.add(Quantit�_lbl_7);
		
		Quantit�_lbl_8 = new JLabel("");
		Quantit�_lbl_8.setVerticalAlignment(SwingConstants.TOP);
		Quantit�_lbl_8.setHorizontalAlignment(SwingConstants.LEFT);
		Quantit�_lbl_8.setFont(new Font("Tahoma", Font.PLAIN, 13));
		Quantit�_lbl_8.setBounds(132, 246, 111, 20);
		contentPane.add(Quantit�_lbl_8);
		
		Quantit�_lbl_9 = new JLabel("");
		Quantit�_lbl_9.setVerticalAlignment(SwingConstants.TOP);
		Quantit�_lbl_9.setHorizontalAlignment(SwingConstants.LEFT);
		Quantit�_lbl_9.setFont(new Font("Tahoma", Font.PLAIN, 13));
		Quantit�_lbl_9.setBounds(132, 268, 111, 20);
		contentPane.add(Quantit�_lbl_9);
		
		Quantit�_lbl_10 = new JLabel("");
		Quantit�_lbl_10.setVerticalAlignment(SwingConstants.TOP);
		Quantit�_lbl_10.setHorizontalAlignment(SwingConstants.LEFT);
		Quantit�_lbl_10.setFont(new Font("Tahoma", Font.PLAIN, 13));
		Quantit�_lbl_10.setBounds(132, 290, 111, 20);
		contentPane.add(Quantit�_lbl_10);
		
		Quantit�_lbl_11 = new JLabel("");
		Quantit�_lbl_11.setVerticalAlignment(SwingConstants.TOP);
		Quantit�_lbl_11.setHorizontalAlignment(SwingConstants.LEFT);
		Quantit�_lbl_11.setFont(new Font("Tahoma", Font.PLAIN, 13));
		Quantit�_lbl_11.setBounds(132, 312, 111, 20);
		contentPane.add(Quantit�_lbl_11);
		
		Quantit�_lbl_12 = new JLabel("");
		Quantit�_lbl_12.setVerticalAlignment(SwingConstants.TOP);
		Quantit�_lbl_12.setHorizontalAlignment(SwingConstants.LEFT);
		Quantit�_lbl_12.setFont(new Font("Tahoma", Font.PLAIN, 13));
		Quantit�_lbl_12.setBounds(132, 334, 111, 20);
		contentPane.add(Quantit�_lbl_12);
		
		Quantit�_lbl_13 = new JLabel("");
		Quantit�_lbl_13.setVerticalAlignment(SwingConstants.TOP);
		Quantit�_lbl_13.setHorizontalAlignment(SwingConstants.LEFT);
		Quantit�_lbl_13.setFont(new Font("Tahoma", Font.PLAIN, 13));
		Quantit�_lbl_13.setBounds(132, 356, 111, 20);
		contentPane.add(Quantit�_lbl_13);
		
		Quantit�_lbl_14 = new JLabel("");
		Quantit�_lbl_14.setVerticalAlignment(SwingConstants.TOP);
		Quantit�_lbl_14.setHorizontalAlignment(SwingConstants.LEFT);
		Quantit�_lbl_14.setFont(new Font("Tahoma", Font.PLAIN, 13));
		Quantit�_lbl_14.setBounds(132, 378, 111, 20);
		contentPane.add(Quantit�_lbl_14);
		
		Prezzo_lbl = new JLabel("");
		Prezzo_lbl.setVerticalAlignment(SwingConstants.TOP);
		Prezzo_lbl.setHorizontalAlignment(SwingConstants.LEFT);
		Prezzo_lbl.setFont(new Font("Tahoma", Font.PLAIN, 13));
		Prezzo_lbl.setBounds(324, 69, 87, 20);
		contentPane.add(Prezzo_lbl);
		
		Prezzo_lbl_1 = new JLabel("");
		Prezzo_lbl_1.setVerticalAlignment(SwingConstants.TOP);
		Prezzo_lbl_1.setHorizontalAlignment(SwingConstants.LEFT);
		Prezzo_lbl_1.setFont(new Font("Tahoma", Font.PLAIN, 13));
		Prezzo_lbl_1.setBounds(324, 92, 87, 20);
		contentPane.add(Prezzo_lbl_1);
		
		Prezzo_lbl_2 = new JLabel("");
		Prezzo_lbl_2.setVerticalAlignment(SwingConstants.TOP);
		Prezzo_lbl_2.setHorizontalAlignment(SwingConstants.LEFT);
		Prezzo_lbl_2.setFont(new Font("Tahoma", Font.PLAIN, 13));
		Prezzo_lbl_2.setBounds(324, 114, 87, 20);
		contentPane.add(Prezzo_lbl_2);
		
		Prezzo_lbl_3 = new JLabel("");
		Prezzo_lbl_3.setVerticalAlignment(SwingConstants.TOP);
		Prezzo_lbl_3.setHorizontalAlignment(SwingConstants.LEFT);
		Prezzo_lbl_3.setFont(new Font("Tahoma", Font.PLAIN, 13));
		Prezzo_lbl_3.setBounds(324, 136, 87, 20);
		contentPane.add(Prezzo_lbl_3);
		
		Prezzo_lbl_4 = new JLabel("");
		Prezzo_lbl_4.setVerticalAlignment(SwingConstants.TOP);
		Prezzo_lbl_4.setHorizontalAlignment(SwingConstants.LEFT);
		Prezzo_lbl_4.setFont(new Font("Tahoma", Font.PLAIN, 13));
		Prezzo_lbl_4.setBounds(324, 158, 87, 20);
		contentPane.add(Prezzo_lbl_4);
		
		Prezzo_lbl_5 = new JLabel("");
		Prezzo_lbl_5.setVerticalAlignment(SwingConstants.TOP);
		Prezzo_lbl_5.setHorizontalAlignment(SwingConstants.LEFT);
		Prezzo_lbl_5.setFont(new Font("Tahoma", Font.PLAIN, 13));
		Prezzo_lbl_5.setBounds(324, 180, 87, 20);
		contentPane.add(Prezzo_lbl_5);
		
		Prezzo_lbl_6 = new JLabel("");
		Prezzo_lbl_6.setVerticalAlignment(SwingConstants.TOP);
		Prezzo_lbl_6.setHorizontalAlignment(SwingConstants.LEFT);
		Prezzo_lbl_6.setFont(new Font("Tahoma", Font.PLAIN, 13));
		Prezzo_lbl_6.setBounds(324, 202, 87, 20);
		contentPane.add(Prezzo_lbl_6);
		
		Prezzo_lbl_7 = new JLabel("");
		Prezzo_lbl_7.setVerticalAlignment(SwingConstants.TOP);
		Prezzo_lbl_7.setHorizontalAlignment(SwingConstants.LEFT);
		Prezzo_lbl_7.setFont(new Font("Tahoma", Font.PLAIN, 13));
		Prezzo_lbl_7.setBounds(324, 224, 87, 20);
		contentPane.add(Prezzo_lbl_7);
		
		Prezzo_lbl_8 = new JLabel("");
		Prezzo_lbl_8.setVerticalAlignment(SwingConstants.TOP);
		Prezzo_lbl_8.setHorizontalAlignment(SwingConstants.LEFT);
		Prezzo_lbl_8.setFont(new Font("Tahoma", Font.PLAIN, 13));
		Prezzo_lbl_8.setBounds(324, 246, 87, 20);
		contentPane.add(Prezzo_lbl_8);
		
		Prezzo_lbl_9 = new JLabel("");
		Prezzo_lbl_9.setVerticalAlignment(SwingConstants.TOP);
		Prezzo_lbl_9.setHorizontalAlignment(SwingConstants.LEFT);
		Prezzo_lbl_9.setFont(new Font("Tahoma", Font.PLAIN, 13));
		Prezzo_lbl_9.setBounds(324, 268, 87, 20);
		contentPane.add(Prezzo_lbl_9);
		
		Prezzo_lbl_10 = new JLabel("");
		Prezzo_lbl_10.setVerticalAlignment(SwingConstants.TOP);
		Prezzo_lbl_10.setHorizontalAlignment(SwingConstants.LEFT);
		Prezzo_lbl_10.setFont(new Font("Tahoma", Font.PLAIN, 13));
		Prezzo_lbl_10.setBounds(324, 290, 87, 20);
		contentPane.add(Prezzo_lbl_10);
		
		Prezzo_lbl_11 = new JLabel("");
		Prezzo_lbl_11.setVerticalAlignment(SwingConstants.TOP);
		Prezzo_lbl_11.setHorizontalAlignment(SwingConstants.LEFT);
		Prezzo_lbl_11.setFont(new Font("Tahoma", Font.PLAIN, 13));
		Prezzo_lbl_11.setBounds(324, 312, 87, 20);
		contentPane.add(Prezzo_lbl_11);
		
		Prezzo_lbl_12 = new JLabel("");
		Prezzo_lbl_12.setVerticalAlignment(SwingConstants.TOP);
		Prezzo_lbl_12.setHorizontalAlignment(SwingConstants.LEFT);
		Prezzo_lbl_12.setFont(new Font("Tahoma", Font.PLAIN, 13));
		Prezzo_lbl_12.setBounds(324, 334, 87, 20);
		contentPane.add(Prezzo_lbl_12);
		
		Prezzo_lbl_13 = new JLabel("");
		Prezzo_lbl_13.setVerticalAlignment(SwingConstants.TOP);
		Prezzo_lbl_13.setHorizontalAlignment(SwingConstants.LEFT);
		Prezzo_lbl_13.setFont(new Font("Tahoma", Font.PLAIN, 13));
		Prezzo_lbl_13.setBounds(324, 356, 87, 20);
		contentPane.add(Prezzo_lbl_13);
		
		Prezzo_lbl_14 = new JLabel("");
		Prezzo_lbl_14.setVerticalAlignment(SwingConstants.TOP);
		Prezzo_lbl_14.setHorizontalAlignment(SwingConstants.LEFT);
		Prezzo_lbl_14.setFont(new Font("Tahoma", Font.PLAIN, 13));
		Prezzo_lbl_14.setBounds(324, 378, 87, 20);
		contentPane.add(Prezzo_lbl_14);
		
		JLabel Prezzototale = new JLabel("Prezzo Totale:");
		Prezzototale.setVerticalAlignment(SwingConstants.TOP);
		Prezzototale.setHorizontalAlignment(SwingConstants.RIGHT);
		Prezzototale.setFont(new Font("Tahoma", Font.PLAIN, 13));
		Prezzototale.setBounds(132, 417, 111, 20);
		contentPane.add(Prezzototale);
		
		Prezzo_tot_lbl = new JLabel("0");
		Prezzo_tot_lbl.setVerticalAlignment(SwingConstants.TOP);
		Prezzo_tot_lbl.setHorizontalAlignment(SwingConstants.LEFT);
		Prezzo_tot_lbl.setFont(new Font("Tahoma", Font.PLAIN, 13));
		Prezzo_tot_lbl.setBounds(251, 417, 87, 20);
		contentPane.add(Prezzo_tot_lbl);
		
		JButton ConfermaButton = new JButton("Conferma");
		ConfermaButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				if(ProdottiInCarrello_lbl.getText().length()>0) {
				IlController.ApriFinestraLogin();
				}
				
			}
		});
		ConfermaButton.setBounds(300, 436, 111, 23);
		contentPane.add(ConfermaButton);
		
		SvuotaCarrelloButton = new JButton("Svuota Carrello");
		SvuotaCarrelloButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				c.SvuotaCarrello();
			}
		});
		SvuotaCarrelloButton.setBounds(153, 436, 137, 23);
		contentPane.add(SvuotaCarrelloButton);
	}
}
