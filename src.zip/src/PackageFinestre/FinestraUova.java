package PackageFinestre;
import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JToggleButton;

import PackageController.Controller;
public class FinestraUova extends JFrame {

	private JPanel contentPane;
	private JTextField Quantit�_TF;
	public Controller IlController;
	private double Quantit�DaSottrarreDouble;
	public JTextField PrezzoAlKilo_TF;
	public JTextField DispInMagazzino_TF;
	private double PrezzoAlKiloDouble;
	private JTextField SimboloEuro;
	private String DispInMagazzinoString;
	
	
	public String getDispInMagazzinoString() {
		return DispInMagazzinoString;
	}
	public void setDispInMagazzinoString(String dispInMagazzinoString) {
		DispInMagazzinoString = dispInMagazzinoString;
	}
	public void setQuantit�DaSottrarreDouble(double quantit�DaSottrarreDouble) {
		Quantit�DaSottrarreDouble = 0.0;
	}
	public double getQuantit�DaSottrarreDouble() {
		return Quantit�DaSottrarreDouble;
	}
	
	public double getPrezzoAlKiloDouble() {
		return PrezzoAlKiloDouble;
	}
	


	/**
	 * Create the frame.
	 */
	public FinestraUova(Controller c) {
		
		IlController=c;
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 498, 339);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel Uova_JLb = new JLabel("Uova");
		Uova_JLb.setHorizontalAlignment(SwingConstants.CENTER);
		Uova_JLb.setFont(new Font("Cambria", Font.PLAIN, 20));
		Uova_JLb.setBounds(187, 0, 109, 25);
		contentPane.add(Uova_JLb);
		
		JLabel Quantit�_JLb = new JLabel("Quantit\u00E0(in chili) che desidera aquistare:");
		Quantit�_JLb.setFont(new Font("Cambria", Font.PLAIN, 14));
		Quantit�_JLb.setBounds(10, 135, 261, 23);
		contentPane.add(Quantit�_JLb);
		
		JButton AvantiButton = new JButton("Avanti");
		AvantiButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

					IlController.prod = IlController.ConnettiAlDB("Uova");
					if((Double.valueOf(Quantit�_TF.getText()))<=(Double.valueOf(DispInMagazzino_TF.getText()))) {
						Quantit�_TF.setEditable(false);
						c.prod.setQuantit�(Double.valueOf(Quantit�_TF.getText()));
						setVisible(false);
						IlController.InfoProdotto();
						IlController.ConfermaProdottoWindow.setVisible(true);
						} else {
							c.aqm_dialog.setVisible(true);
						}

				
			}
		});
		AvantiButton.setBounds(318, 265, 154, 23);
		contentPane.add(AvantiButton);
		
		Quantit�_TF = new JTextField();
		Quantit�_TF.setText("0");
		Quantit�_TF.setEditable(false);
		Quantit�_TF.setFont(new Font("Cambria", Font.PLAIN, 13));
		Quantit�_TF.setHorizontalAlignment(SwingConstants.CENTER);
		Quantit�_TF.setToolTipText("Inserire quantit\u00E0 desiderata");
		Quantit�_TF.setBounds(320, 137, 79, 20);
		contentPane.add(Quantit�_TF);
		Quantit�_TF.setColumns(10);
		
		JLabel PrezzoAlKilo_JLb = new JLabel("Prezzo al Chilo:");
		PrezzoAlKilo_JLb.setFont(new Font("Cambria", Font.PLAIN, 14));
		PrezzoAlKilo_JLb.setBounds(10, 95, 109, 14);
		contentPane.add(PrezzoAlKilo_JLb);
		
		PrezzoAlKilo_TF = new JTextField("");
		PrezzoAlKilo_TF.setFont(new Font("Cambria", Font.PLAIN, 13));
		PrezzoAlKilo_TF.setHorizontalAlignment(SwingConstants.CENTER);
		PrezzoAlKilo_TF.setEditable(false);
		PrezzoAlKilo_TF.setBounds(108, 92, 35, 20);
		contentPane.add(PrezzoAlKilo_TF);
		PrezzoAlKilo_TF.setColumns(10);
		
		JLabel DispInMagazzino_JLb = new JLabel("Disponibilit\u00E0 in magazzino:");
		DispInMagazzino_JLb.setFont(new Font("Cambria", Font.PLAIN, 15));
		DispInMagazzino_JLb.setBounds(10, 50, 257, 17);
		contentPane.add(DispInMagazzino_JLb);
		
		DispInMagazzino_TF = new JTextField();
		DispInMagazzino_TF.setFont(new Font("Cambria", Font.PLAIN, 14));
		DispInMagazzino_TF.setHorizontalAlignment(SwingConstants.LEFT);
		DispInMagazzino_TF.setEditable(false);
		DispInMagazzino_TF.setBounds(197, 49, 214, 20);
		contentPane.add(DispInMagazzino_TF);
		DispInMagazzino_TF.setColumns(10);
		

		JButton TornaHomeButton = new JButton("Torna alla home");
		TornaHomeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c.TornaAllaHome();
			}
		});
		TornaHomeButton.setBounds(10, 267, 154, 23);
		contentPane.add(TornaHomeButton);
		
		SimboloEuro = new JTextField();
		SimboloEuro.setEditable(false);
		SimboloEuro.setFont(new Font("Cambria", Font.PLAIN, 13));
		SimboloEuro.setHorizontalAlignment(SwingConstants.CENTER);
		SimboloEuro.setText("\u20AC");
		SimboloEuro.setBounds(142, 92, 18, 20);
		contentPane.add(SimboloEuro);
		SimboloEuro.setColumns(10);
		
		JButton PiuButton = new JButton("+");
		PiuButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int tmp = Integer.parseInt(Quantit�_TF.getText());
				Quantit�_TF.setText(String.valueOf(tmp+1));
			}
		});
		PiuButton.setBounds(400, 137, 49, 20);
		contentPane.add(PiuButton);
		
		JButton MenoButton = new JButton("-");
		MenoButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int tmp = Integer.parseInt(Quantit�_TF.getText());
				if(Integer.parseInt(Quantit�_TF.getText())>0) {
				Quantit�_TF.setText(String.valueOf(tmp-1));
				}
			}
		});
		MenoButton.setBounds(270, 137, 49, 20);
		contentPane.add(MenoButton);
		
	}
	
}