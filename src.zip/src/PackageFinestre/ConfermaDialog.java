package PackageFinestre;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import PackageController.Controller;

import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ConfermaDialog extends JDialog {

	private final JPanel contentPanel = new JPanel();
	public Controller IlController;
	int i;
	/**
	 * Create the dialog.
	 */
	public ConfermaDialog(Controller c) {
		IlController = c;
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel lblNewLabel = new JLabel("Confermi l'acquisto?");
			lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 16));
			lblNewLabel.setBounds(142, 99, 149, 30);
			contentPanel.add(lblNewLabel);
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						for(i=0; i<c.ConfermaProdottoWindow.contatore; i++) {
							if(i==0) {
								c.carrellodao.ScalaDisp(Double.valueOf(c.CarrelloWindow.Quantit�_lbl.getText()), c.CarrelloWindow.ProdottiInCarrello_lbl.getText());
							}
							if(i==1) {
								c.carrellodao.ScalaDisp(Double.valueOf(c.CarrelloWindow.Quantit�_lbl_1.getText()), c.CarrelloWindow.ProdottiInCarrello2_lbl.getText());
							}
							if(i==2) {
								c.carrellodao.ScalaDisp(Double.valueOf(c.CarrelloWindow.Quantit�_lbl_2.getText()), c.CarrelloWindow.ProdottiInCarrello3_lbl.getText());
							}
							if(i==3) {
								c.carrellodao.ScalaDisp(Double.valueOf(c.CarrelloWindow.Quantit�_lbl_3.getText()), c.CarrelloWindow.ProdottiInCarrello4_lbl.getText());
							}
							if(i==4) {
								c.carrellodao.ScalaDisp(Double.valueOf(c.CarrelloWindow.Quantit�_lbl_4.getText()), c.CarrelloWindow.ProdottiInCarrello5_lbl.getText());
							}
							if(i==5) {
								c.carrellodao.ScalaDisp(Double.valueOf(c.CarrelloWindow.Quantit�_lbl_5.getText()), c.CarrelloWindow.ProdottiInCarrello6_lbl.getText());
							}
							if(i==6) {
								c.carrellodao.ScalaDisp(Double.valueOf(c.CarrelloWindow.Quantit�_lbl_6.getText()), c.CarrelloWindow.ProdottiInCarrello7_lbl.getText());
							}
							if(i==7) {
								c.carrellodao.ScalaDisp(Double.valueOf(c.CarrelloWindow.Quantit�_lbl_7.getText()), c.CarrelloWindow.ProdottiInCarrello8_lbl.getText());
							}
							if(i==8) {
								c.carrellodao.ScalaDisp(Double.valueOf(c.CarrelloWindow.Quantit�_lbl_8.getText()), c.CarrelloWindow.ProdottiInCarrello9_lbl.getText());
							}
							if(i==9) {
								c.carrellodao.ScalaDisp(Double.valueOf(c.CarrelloWindow.Quantit�_lbl_9.getText()), c.CarrelloWindow.ProdottiInCarrello10_lbl.getText());
							}
							if(i==10) {
								c.carrellodao.ScalaDisp(Double.valueOf(c.CarrelloWindow.Quantit�_lbl_10.getText()), c.CarrelloWindow.ProdottiInCarrello11_lbl.getText());
							}
							if(i==11) {
								c.carrellodao.ScalaDisp(Double.valueOf(c.CarrelloWindow.Quantit�_lbl_11.getText()), c.CarrelloWindow.ProdottiInCarrello12_lbl.getText());
							}
							if(i==12) {
								c.carrellodao.ScalaDisp(Double.valueOf(c.CarrelloWindow.Quantit�_lbl_12.getText()), c.CarrelloWindow.ProdottiInCarrello13_lbl.getText());
							}
							if(i==13) {
								c.carrellodao.ScalaDisp(Double.valueOf(c.CarrelloWindow.Quantit�_lbl_13.getText()), c.CarrelloWindow.ProdottiInCarrello14_lbl.getText());
							}
							if(i==14) {
								c.carrellodao.ScalaDisp(Double.valueOf(c.CarrelloWindow.Quantit�_lbl_14.getText()), c.CarrelloWindow.ProdottiInCarrello15_lbl.getText());
							}
						}
						setVisible(false);
						c.clientedao.AssegnaPunti((int)c.CarrelloWindow.prezzo_tot/10, c.LoginWindow.Username_TF.getText());
						c.CarrelloWindow.setVisible(false);
						c.SvuotaCarrello();
						c.TornaAllaHome();
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						setVisible(false);
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}

}
