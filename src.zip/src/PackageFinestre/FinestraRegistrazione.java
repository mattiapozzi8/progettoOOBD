package PackageFinestre;

import PackageController.*;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import java.sql.*;
import javax.swing.JPasswordField;

public class FinestraRegistrazione extends JFrame {

	private JPanel contentPane;
	private JTextField newusername;

	Controller theController;
	NewDialog2 n2 = new NewDialog2(theController);
	private JPasswordField newpassword;
	
	/**
	 * Create the frame.
	 */
	public FinestraRegistrazione(Controller c) {
		theController = c;
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("BENVENUTO!");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel.setBounds(0, 11, 434, 26);
		contentPane.add(lblNewLabel);
		
		newusername = new JTextField();
		newusername.setBounds(221, 69, 117, 20);
		contentPane.add(newusername);
		newusername.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Username");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1.setFont(new Font("Calibri", Font.PLAIN, 13));
		lblNewLabel_1.setBounds(123, 74, 88, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Password");
		lblNewLabel_2.setFont(new Font("Calibri", Font.PLAIN, 13));
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_2.setBounds(133, 107, 78, 14);
		contentPane.add(lblNewLabel_2);
		
		JButton btnNewButton = new JButton("Avanti");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				if(newusername.getText().length()>0 && newpassword.getText().length()>0) {
					
					theController.clientedao.RegistraCliente(newusername.getText(), newpassword.getText());
					theController.clientedao.RegistraTessera(newusername.getText());
					
					setVisible(false);
					theController.LoginWindow.setVisible(true);
					
				} else {
					n2.setVisible(true);
				}
				
			}
		});
		btnNewButton.setBounds(335, 227, 89, 23);
		contentPane.add(btnNewButton);
		
		newpassword = new JPasswordField();
		newpassword.setBounds(221, 100, 117, 20);
		contentPane.add(newpassword);
	}
}
