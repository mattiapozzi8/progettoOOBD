package PackageFinestre;

import PackageController.*;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import java.sql.*;
import javax.swing.JPasswordField;

public class FinestraRegistrazione extends JFrame {

	private JPanel contentPane;
	private JTextField newusername;

	Controller theController;
	NewDialog2 n2 = new NewDialog2(theController);
	private JPasswordField newpassword;
	
	/**
	 * Create the frame.
	 */
	public FinestraRegistrazione(Controller c) {
		setTitle("Registrazione");
		theController = c;
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel benvenuto_lbl = new JLabel("BENVENUTO!");
		benvenuto_lbl.setHorizontalAlignment(SwingConstants.CENTER);
		benvenuto_lbl.setFont(new Font("Arial Black", Font.PLAIN, 20));
		benvenuto_lbl.setBounds(0, 11, 434, 26);
		contentPane.add(benvenuto_lbl);
		
		newusername = new JTextField();
		newusername.setBounds(221, 69, 117, 20);
		contentPane.add(newusername);
		newusername.setColumns(10);
		
		JLabel user_lbl = new JLabel("Username");
		user_lbl.setHorizontalAlignment(SwingConstants.RIGHT);
		user_lbl.setFont(new Font("Calibri", Font.PLAIN, 13));
		user_lbl.setBounds(123, 74, 88, 14);
		contentPane.add(user_lbl);
		
		JLabel pass_lbl = new JLabel("Password");
		pass_lbl.setFont(new Font("Calibri", Font.PLAIN, 13));
		pass_lbl.setHorizontalAlignment(SwingConstants.RIGHT);
		pass_lbl.setBounds(133, 107, 78, 14);
		contentPane.add(pass_lbl);
		
		JButton AvantiButton = new JButton("Avanti");
		AvantiButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				if(newusername.getText().length()>0 && newpassword.getText().length()>0) {
					
					theController.clientedao.RegistraCliente(newusername.getText(), newpassword.getText());
					theController.clientedao.RegistraTessera(newusername.getText());
					newusername.setText("");
					newpassword.setText("");
					
					setVisible(false);
					
				} else {
					n2.setVisible(true);
				}
				
			}
		});
		AvantiButton.setBounds(335, 227, 89, 23);
		contentPane.add(AvantiButton);
		
		newpassword = new JPasswordField();
		newpassword.setBounds(221, 100, 117, 20);
		contentPane.add(newpassword);
		
		JButton IndietroButton = new JButton("Indietro");
		IndietroButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				setVisible(false);
			}
		});
		IndietroButton.setBounds(10, 227, 102, 23);
		contentPane.add(IndietroButton);
	}
}
