package PackageFinestre;
import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JToggleButton;

import PackageController.Controller;
public class FinestraConfezionati extends JFrame {

	private JPanel contentPane;
	public JTextField Quantit�_TF;
	public Controller IlController;
	private double Quantit�DaSottrarreDouble;
	private JTextField PrezzoAlKilo_TF;
	private JTextField DispInMagazzino_TF;
	private double PrezzoAlKiloDouble;
	private JTextField SimboloEuro;
	private String DispInMagazzinoString;
	private JTextField SelezionaConfezionati_TF;
	private String TipoConfezionati;
	private String CopiaTipoConfezionati;
	public int disp_tot = 0;
	public 	JButton PiuButton=new JButton("+");

	public String getCopiaTipoConfezionati() {
		return CopiaTipoConfezionati;
	}
	public void setCopiaTipoConfezionati(String tipoConfezionati) {
		CopiaTipoConfezionati = tipoConfezionati;
	}
	public String getDispInMagazzinoString() {
		return DispInMagazzinoString;
	}
	public void setDispInMagazzinoString(String dispInMagazzinoString) {
		DispInMagazzinoString = dispInMagazzinoString;
	}
	public void setQuantit�DaSottrarreDouble(double quantit�DaSottrarreDouble) {
		Quantit�DaSottrarreDouble = 0.0;
	}
	public double getQuantit�DaSottrarreDouble() {
		return Quantit�DaSottrarreDouble;
	}
	
	public double getPrezzoAlKiloDouble() {
		return PrezzoAlKiloDouble;
	}
	


	/**
	 * Create the frame.
	 */
	public FinestraConfezionati(Controller c) {
		
		IlController=c;
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 498, 339);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel Confezionati_JLb = new JLabel("Confezionati");
		Confezionati_JLb.setHorizontalAlignment(SwingConstants.CENTER);
		Confezionati_JLb.setFont(new Font("Cambria", Font.PLAIN, 20));
		Confezionati_JLb.setBounds(187, 0, 109, 25);
		contentPane.add(Confezionati_JLb);
		
		JLabel Quantit�_JLb = new JLabel("Quantit\u00E0 (in chili) che desidera aquistare:");
		Quantit�_JLb.setFont(new Font("Cambria", Font.PLAIN, 14));
		Quantit�_JLb.setBounds(10, 145, 261, 16);
		contentPane.add(Quantit�_JLb);
		
		Quantit�_TF = new JTextField();
		Quantit�_TF.setEditable(false);
		Quantit�_TF.setText("0");
		Quantit�_TF.setFont(new Font("Cambria", Font.PLAIN, 13));
		Quantit�_TF.setHorizontalAlignment(SwingConstants.CENTER);
		Quantit�_TF.setToolTipText("Inserire quantit\u00E0 desiderata");
		Quantit�_TF.setBounds(321, 144, 78, 20);
		contentPane.add(Quantit�_TF);
		Quantit�_TF.setColumns(10);
		
		JButton AvantiButton = new JButton("Avanti");
		AvantiButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
//				String Quantit�DaSottrarreString=Quantit�_TF.getText();
//				try {
//					Quantit�DaSottrarreDouble = Double.parseDouble(Quantit�DaSottrarreString);	
//				}
//				catch (NumberFormatException Nfe){
//					System.err.println("");
//				}
//				DispInMagazzinoString=c.SottraiQuantit�();
//				DispInMagazzino_TF.setText(DispInMagazzinoString);
//				if((DispInMagazzinoString.equals("Non ci sono abbastanza scorte"))){
//					Quantit�_TF.setEditable(false);
//				}
//					else {
//						DispInMagazzino_TF.setText(DispInMagazzinoString);
						Quantit�_TF.setEditable(false);
						c.prod.setQuantit�(Double.valueOf(Quantit�_TF.getText()));
						setVisible(false);
						IlController.InfoProdotto();
						IlController.ConfermaProdottoWindow.setVisible(true);
//					}
				
			}
		});
		AvantiButton.setBounds(318, 265, 154, 23);
		contentPane.add(AvantiButton);
		
		JLabel PrezzoAlKilo_JLb = new JLabel(" Prezzo al Chilo:");
		PrezzoAlKilo_JLb.setFont(new Font("Cambria", Font.PLAIN, 15));
		PrezzoAlKilo_JLb.setBounds(9, 110, 109, 14);
		contentPane.add(PrezzoAlKilo_JLb);
		
		PrezzoAlKilo_TF = new JTextField();
		PrezzoAlKilo_TF.setFont(new Font("Cambria", Font.PLAIN, 13));
		PrezzoAlKilo_TF.setHorizontalAlignment(SwingConstants.CENTER);
		PrezzoAlKilo_TF.setEditable(false);
		PrezzoAlKilo_TF.setBounds(114, 108, 35, 20);
		contentPane.add(PrezzoAlKilo_TF);
		PrezzoAlKilo_TF.setColumns(10);
		
		JLabel DispInMagazzino_JLb = new JLabel("Disponibilit\u00E0 in magazzino:");
		DispInMagazzino_JLb.setFont(new Font("Cambria", Font.PLAIN, 15));
		DispInMagazzino_JLb.setBounds(10, 71, 176, 25);
		contentPane.add(DispInMagazzino_JLb);
		
		DispInMagazzino_TF = new JTextField();
		DispInMagazzino_TF.setFont(new Font("Cambria", Font.PLAIN, 14));
		DispInMagazzino_TF.setHorizontalAlignment(SwingConstants.LEFT);
		DispInMagazzino_TF.setEditable(false);
		DispInMagazzino_TF.setBounds(187, 74, 262, 20);
		contentPane.add(DispInMagazzino_TF);
		DispInMagazzino_TF.setColumns(10);
		

		JButton TornaHomeButton = new JButton("Torna alla home");
		TornaHomeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c.TornaAllaHome();
			}
		});
		TornaHomeButton.setBounds(10, 265, 154, 23);
		contentPane.add(TornaHomeButton);
		
		SimboloEuro = new JTextField();
		SimboloEuro.setEditable(false);
		SimboloEuro.setFont(new Font("Cambria", Font.PLAIN, 13));
		SimboloEuro.setHorizontalAlignment(SwingConstants.CENTER);
		SimboloEuro.setText("\u20AC");
		SimboloEuro.setBounds(148, 108, 18, 20);
		contentPane.add(SimboloEuro);
		SimboloEuro.setColumns(10);
		
		JComboBox ConfezionatiComboBox = new JComboBox();
		
		ConfezionatiComboBox.setModel(new DefaultComboBoxModel(new String[] {"Caff\u00E8", "Cioccolata", "Prosciutto", "Mortadella", "Salame", "Gelato"}));
		ConfezionatiComboBox.setToolTipText("");
		ConfezionatiComboBox.setSelectedItem(null);
		ConfezionatiComboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				TipoConfezionati = (String) ConfezionatiComboBox.getSelectedItem();
				
				
				if(TipoConfezionati.equals("Caff�")) {
					IlController.prod = IlController.ConnettiAlDB("Caff�");
					PrezzoAlKilo_TF.setText(String.valueOf(IlController.ConnettiAlDB("Caff�").getPrezzoAlKilo()));
					disp_tot = IlController.ConnettiAlDB("Caff�").getDisponibilit�();
					DispInMagazzino_TF.setText(String.valueOf(disp_tot));

				}
				
				if(TipoConfezionati.equals("Cioccolata")) {
					IlController.prod = IlController.ConnettiAlDB("Cioccolata");
					PrezzoAlKilo_TF.setText(String.valueOf(IlController.ConnettiAlDB("Cioccolata").getPrezzoAlKilo()));
					disp_tot = IlController.ConnettiAlDB("Cioccolata").getDisponibilit�();
					DispInMagazzino_TF.setText(String.valueOf(disp_tot));
				}
				
				if(TipoConfezionati.equals("Prosciutto")) {
					IlController.prod = IlController.ConnettiAlDB("Prosciutto");
					PrezzoAlKilo_TF.setText(String.valueOf(IlController.ConnettiAlDB("Prosciutto").getPrezzoAlKilo()));
					disp_tot = IlController.ConnettiAlDB("Prosciutto").getDisponibilit�();
					DispInMagazzino_TF.setText(String.valueOf(disp_tot));
				}

				if(TipoConfezionati.equals("Mortadella")) {
					IlController.prod = IlController.ConnettiAlDB("Mortadella");
					PrezzoAlKilo_TF.setText(String.valueOf(IlController.ConnettiAlDB("Mortadella").getPrezzoAlKilo()));
					disp_tot = IlController.ConnettiAlDB("Mortadella").getDisponibilit�();
					DispInMagazzino_TF.setText(String.valueOf(disp_tot));
				}
				
				if(TipoConfezionati.equals("Salame")) {
					IlController.prod = IlController.ConnettiAlDB("Salame");
					PrezzoAlKilo_TF.setText(String.valueOf(IlController.ConnettiAlDB("Salame").getPrezzoAlKilo()));
					disp_tot = IlController.ConnettiAlDB("Salame").getDisponibilit�();
					DispInMagazzino_TF.setText(String.valueOf(disp_tot));
				}
				
				if(TipoConfezionati.equals("Gelato")) {
					IlController.prod = IlController.ConnettiAlDB("Gelato");
					PrezzoAlKilo_TF.setText(String.valueOf(IlController.ConnettiAlDB("Gelato").getPrezzoAlKilo()));
					disp_tot = IlController.ConnettiAlDB("Gelato").getDisponibilit�();
					DispInMagazzino_TF.setText(String.valueOf(disp_tot));
				}
				
				
			}
		});
		
		
		ConfezionatiComboBox.setBounds(134, 36, 109, 24);
		contentPane.add(ConfezionatiComboBox);
		
		SelezionaConfezionati_TF = new JTextField();
		SelezionaConfezionati_TF.setEditable(false);
		SelezionaConfezionati_TF.setFont(new Font("Cambria", Font.PLAIN, 14));
		SelezionaConfezionati_TF.setText("Seleziona Confezionati:");
		SelezionaConfezionati_TF.setBounds(10, 36, 121, 25);
		contentPane.add(SelezionaConfezionati_TF);
		SelezionaConfezionati_TF.setColumns(10);
		
		JButton PiuButton = new JButton("+");
		PiuButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int tmp = Integer.parseInt(Quantit�_TF.getText());
				Quantit�_TF.setText(String.valueOf(tmp+1));		
				if(tmp==49)
					PiuButton.setEnabled(false);
			}
		});
		PiuButton.setBounds(400, 144, 49, 20);
		contentPane.add(PiuButton);
		
		JButton MenoButton = new JButton("-");
		MenoButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int tmp = Integer.parseInt(Quantit�_TF.getText());
				if(Integer.parseInt(Quantit�_TF.getText())>0) {
				Quantit�_TF.setText(String.valueOf(tmp-1));
				}
				if(tmp<52)
					PiuButton.setEnabled(true);
			}
		});
		MenoButton.setBounds(270, 144, 49, 20);
		contentPane.add(MenoButton);
		
	}
	
}