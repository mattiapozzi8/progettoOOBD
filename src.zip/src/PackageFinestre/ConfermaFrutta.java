package PackageFinestre;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import PackageController.Controller;
import PackageEntit�.Frutta;

import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JTextField;

public class ConfermaFrutta extends JFrame {

	private JPanel contentPane;
	Controller IlController;
	Frutta fruit = new Frutta();
	public JTextField TipoFrutta_TF;
	public JLabel marca_lbl;
	public JLabel id_lbl;
	public JLabel prezzo_lbl;
	public JLabel scadenza_lbl;
	public JLabel raccolta_lbl;
	public JLabel conservazione_lbl;
	public JTextField marca_TF;
	public JTextField id_TF;
	public JTextField prezzo_TF;
	public JTextField scadenza_TF;
	public JTextField raccolta_TF;
	public JTextField conservazione_TF;


	public ConfermaFrutta(Controller c) {
		IlController = c;
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton TornaHomeButton = new JButton("Torna alla home");
		TornaHomeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				IlController.TornaAllaHome();
			}
		});
		TornaHomeButton.setBounds(10, 229, 154, 22);
		contentPane.add(TornaHomeButton);
		
		TipoFrutta_TF = new JTextField();
		TipoFrutta_TF.setFont(new Font("Cambria", Font.PLAIN, 18));
		TipoFrutta_TF.setHorizontalAlignment(SwingConstants.CENTER);
		TipoFrutta_TF.setEditable(false);
		TipoFrutta_TF.setBounds(10, 11, 414, 32);
		contentPane.add(TipoFrutta_TF);
		TipoFrutta_TF.setColumns(10);
		
		marca_lbl = new JLabel("Marca:");
		marca_lbl.setFont(new Font("Cambria", Font.PLAIN, 12));
		marca_lbl.setBounds(10, 54, 48, 14);
		contentPane.add(marca_lbl);
		
		id_lbl = new JLabel("Codice prodotto:");
		id_lbl.setFont(new Font("Cambria", Font.PLAIN, 12));
		id_lbl.setBounds(10, 79, 92, 14);
		contentPane.add(id_lbl);
		
		prezzo_lbl = new JLabel("Prezzo:");
		prezzo_lbl.setFont(new Font("Cambria", Font.PLAIN, 12));
		prezzo_lbl.setBounds(10, 104, 48, 14);
		contentPane.add(prezzo_lbl);
		
		scadenza_lbl = new JLabel("Data scadenza:");
		scadenza_lbl.setFont(new Font("Cambria", Font.PLAIN, 12));
		scadenza_lbl.setBounds(10, 129, 77, 14);
		contentPane.add(scadenza_lbl);
		
		raccolta_lbl = new JLabel("Data raccolta:");
		raccolta_lbl.setFont(new Font("Cambria", Font.PLAIN, 12));
		raccolta_lbl.setBounds(10, 154, 77, 14);
		contentPane.add(raccolta_lbl);
		
		conservazione_lbl = new JLabel("Modalit\u00E0 conservazione:");
		conservazione_lbl.setFont(new Font("Cambria", Font.PLAIN, 12));
		conservazione_lbl.setBounds(10, 179, 124, 14);
		contentPane.add(conservazione_lbl);
		
		marca_TF = new JTextField();
		marca_TF.setFont(new Font("Cambria", Font.PLAIN, 12));
		marca_TF.setEditable(false);
		marca_TF.setBounds(48, 52, 376, 20);
		contentPane.add(marca_TF);
		marca_TF.setColumns(10);
		
		id_TF = new JTextField();
		id_TF.setFont(new Font("Cambria", Font.PLAIN, 12));
		id_TF.setEditable(false);
		id_TF.setColumns(10);
		id_TF.setBounds(99, 77, 325, 20);
		contentPane.add(id_TF);
		
		prezzo_TF = new JTextField();
		prezzo_TF.setFont(new Font("Cambria", Font.PLAIN, 12));
		prezzo_TF.setEditable(false);
		prezzo_TF.setColumns(10);
		prezzo_TF.setBounds(48, 102, 376, 20);
		contentPane.add(prezzo_TF);
		
		scadenza_TF = new JTextField();
		scadenza_TF.setFont(new Font("Cambria", Font.PLAIN, 12));
		scadenza_TF.setEditable(false);
		scadenza_TF.setColumns(10);
		scadenza_TF.setBounds(88, 127, 336, 20);
		contentPane.add(scadenza_TF);
		
		raccolta_TF = new JTextField();
		raccolta_TF.setFont(new Font("Cambria", Font.PLAIN, 12));
		raccolta_TF.setEditable(false);
		raccolta_TF.setColumns(10);
		raccolta_TF.setBounds(81, 152, 343, 20);
		contentPane.add(raccolta_TF);
		
		conservazione_TF = new JTextField();
		conservazione_TF.setFont(new Font("Cambria", Font.PLAIN, 12));
		conservazione_TF.setEditable(false);
		conservazione_TF.setColumns(10);
		conservazione_TF.setBounds(136, 177, 288, 20);
		contentPane.add(conservazione_TF);
	}
}
