package PackageFinestre;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import PackageController.Controller;
import PackageEntit�.Frutta;

import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;

public class ConfermaFrutta extends JFrame {

	private JPanel contentPane;
	Controller IlController;
	Frutta fruit = new Frutta();


	public ConfermaFrutta(Controller c) {
		IlController = c;
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel tipoFrutta_lbl = new JLabel("");
		tipoFrutta_lbl.setFont(new Font("Cambria", Font.PLAIN, 18));
		tipoFrutta_lbl.setHorizontalAlignment(SwingConstants.CENTER);
		tipoFrutta_lbl.setText(fruit.getNomeProdotto());
		tipoFrutta_lbl.setBounds(67, 11, 300, 22);
		contentPane.add(tipoFrutta_lbl);
	}

}
