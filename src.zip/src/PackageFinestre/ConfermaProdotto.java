package PackageFinestre;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import PackageController.Controller;
import PackageEntit�.Frutta;

import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JTextField;

public class ConfermaProdotto extends JFrame {

	private JPanel contentPane;
	Controller IlController;
	public JLabel TipoProdotto_lbl;
	public JLabel marca_lbl;
	public JLabel id_lbl;
	public JLabel prezzo_lbl;
	public JLabel scadenza_lbl;
	public JLabel dynamic1_lbl;
	public JLabel dynamic2_lbl;
	public JLabel marca_lbl2;
	public JLabel id_lbl2;
	public JLabel prezzo_lbl2;
	public JLabel scadenza_lbl2;
	public int contatore=0;


	public ConfermaProdotto(Controller c) {
		IlController = c;
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 355);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton TornaHomeButton = new JButton("Torna alla home");
		TornaHomeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dynamic1_lbl.setText("");
				dynamic2_lbl.setText("");
				IlController.TornaAllaHome();
			}
		});
		TornaHomeButton.setBounds(10, 284, 154, 22);
		contentPane.add(TornaHomeButton);
		
		TipoProdotto_lbl = new JLabel("");
		TipoProdotto_lbl.setFont(new Font("Cambria", Font.PLAIN, 18));
		TipoProdotto_lbl.setHorizontalAlignment(SwingConstants.CENTER);
		TipoProdotto_lbl.setBounds(10, 11, 414, 32);
		contentPane.add(TipoProdotto_lbl);
		
		marca_lbl = new JLabel("Marca:");
		marca_lbl.setFont(new Font("Cambria", Font.PLAIN, 12));
		marca_lbl.setBounds(10, 54, 48, 14);
		contentPane.add(marca_lbl);
		
		id_lbl = new JLabel("Codice prodotto:");
		id_lbl.setFont(new Font("Cambria", Font.PLAIN, 12));
		id_lbl.setBounds(10, 79, 92, 14);
		contentPane.add(id_lbl);
		
		prezzo_lbl = new JLabel("Prezzo al chilo/litro:");
		prezzo_lbl.setFont(new Font("Cambria", Font.PLAIN, 12));
		prezzo_lbl.setBounds(10, 104, 111, 14);
		contentPane.add(prezzo_lbl);
		
		scadenza_lbl = new JLabel("Data scadenza:");
		scadenza_lbl.setFont(new Font("Cambria", Font.PLAIN, 12));
		scadenza_lbl.setBounds(10, 129, 77, 14);
		contentPane.add(scadenza_lbl);
		
		dynamic1_lbl = new JLabel("");
		dynamic1_lbl.setFont(new Font("Cambria", Font.PLAIN, 12));
		dynamic1_lbl.setBounds(10, 154, 414, 20);
		contentPane.add(dynamic1_lbl);
		
		dynamic2_lbl = new JLabel("");
		dynamic2_lbl.setFont(new Font("Cambria", Font.PLAIN, 12));
		dynamic2_lbl.setBounds(10, 182, 414, 20);
		contentPane.add(dynamic2_lbl);
		
		marca_lbl2 = new JLabel("");
		marca_lbl2.setFont(new Font("Cambria", Font.PLAIN, 12));
		marca_lbl2.setBounds(48, 52, 376, 20);
		contentPane.add(marca_lbl2);
		
		id_lbl2 = new JLabel("");
		id_lbl2.setFont(new Font("Cambria", Font.PLAIN, 12));
		id_lbl2.setBounds(99, 76, 325, 20);
		contentPane.add(id_lbl2);
		
		prezzo_lbl2 = new JLabel("");
		prezzo_lbl2.setFont(new Font("Cambria", Font.PLAIN, 12));
		prezzo_lbl2.setBounds(119, 101, 305, 20);
		contentPane.add(prezzo_lbl2);
		
		scadenza_lbl2 = new JLabel("");
		scadenza_lbl2.setFont(new Font("Cambria", Font.PLAIN, 12));
		scadenza_lbl2.setBounds(88, 127, 336, 20);
		contentPane.add(scadenza_lbl2);
		
		JButton InviaAlCarrelloButton = new JButton("Invia al carrello");
		InviaAlCarrelloButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dynamic1_lbl.setText("");
				dynamic2_lbl.setText("");
				c.AggiungiAlCarrello(TipoProdotto_lbl.getText());
				contatore++;
				c.ApriFinestraCarrello();
			}
		});
		InviaAlCarrelloButton.setBounds(275, 284, 149, 23);
		contentPane.add(InviaAlCarrelloButton);
	}
}

