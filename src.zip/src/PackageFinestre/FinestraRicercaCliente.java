package PackageFinestre;
import PackageController.*;
import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;




public class FinestraRicercaCliente extends JFrame {

	public Controller IlController;
	private JPanel contentPane;
	public JTextField RicercaUser_TF;

	

	public FinestraRicercaCliente(Controller c) {
		IlController=c;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 360, 223);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel RicercaCliente_JLb = new JLabel("Ricerca Cliente");
		RicercaCliente_JLb.setFont(new Font("Cambria", Font.PLAIN, 20));
		RicercaCliente_JLb.setHorizontalAlignment(SwingConstants.CENTER);
		RicercaCliente_JLb.setBounds(92, 11, 160, 25);
		contentPane.add(RicercaCliente_JLb);
		
		JLabel InserisciUser_JLb = new JLabel("Inserisci Username:");
		InserisciUser_JLb.setFont(new Font("Cambria", Font.PLAIN, 13));
		InserisciUser_JLb.setHorizontalAlignment(SwingConstants.CENTER);
		InserisciUser_JLb.setBounds(92, 65, 160, 25);
		contentPane.add(InserisciUser_JLb);
		
		RicercaUser_TF = new JTextField();
		RicercaUser_TF.setFont(new Font("Tahoma", Font.PLAIN, 13));
		RicercaUser_TF.setBounds(97, 100, 150, 22);
		contentPane.add(RicercaUser_TF);
		RicercaUser_TF.setColumns(10);
		
		JButton RicercaClienteButton = new JButton("OK");
		RicercaClienteButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(IlController.clientedao.TrovaCliente(RicercaUser_TF.getText())) {
					setVisible(false);
					IlController.ApriFinestraCliente();
					IlController.ClienteWindow.Us_JLb.setText("Benvenuto "+RicercaUser_TF.getText());
					IlController.ClienteWindow.punti_tessera_lbl.setText(String.valueOf(c.clientedao.InfoCliente(RicercaUser_TF.getText())));
				} else {
					IlController.ed.setVisible(true);
				}
			}
		});
		RicercaClienteButton.setBounds(257, 100, 77, 22);
		contentPane.add(RicercaClienteButton);
		
		JButton TornaAllaHomeButton = new JButton("Torna alla home");
		TornaAllaHomeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c.RicercaClienteWindow.setVisible(false);
				c.TornaAllaHome();
			}
		});
		TornaAllaHomeButton.setBounds(193, 151, 141, 23);
		contentPane.add(TornaAllaHomeButton);
	}
}
