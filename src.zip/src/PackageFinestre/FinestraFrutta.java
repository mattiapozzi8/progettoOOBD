package PackageFinestre;
import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JToggleButton;

import PackageController.Controller;
public class FinestraFrutta extends JFrame {

	private JPanel contentPane;
	public JTextField Quantit�_TF;
	public Controller IlController;
	private double Quantit�DaSottrarreDouble;
	private JTextField PrezzoAlKilo_TF;
	private JTextField DispInMagazzino_TF;
	private double PrezzoAlKiloDouble;
	private JTextField SimboloEuro;
	private String DispInMagazzinoString;
	private JTextField SelezionaFrutto_TF;
	private String TipoFrutta;
	private String CopiaTipoFrutta;
	public int disp_tot = 0;
	public 	JButton PiuButton=new JButton("+");
	public JButton AvantiButton = new JButton("Avanti");
	public JComboBox FruttaComboBox = new JComboBox();

	public String getCopiaTipoFrutta() {
		return CopiaTipoFrutta;
	}
	public void setCopiaTipoFrutta(String tipoFrutta) {
		CopiaTipoFrutta = tipoFrutta;
	}
	public String getDispInMagazzinoString() {
		return DispInMagazzinoString;
	}
	public void setDispInMagazzinoString(String dispInMagazzinoString) {
		DispInMagazzinoString = dispInMagazzinoString;
	}
	public void setQuantit�DaSottrarreDouble(double quantit�DaSottrarreDouble) {
		Quantit�DaSottrarreDouble = 0.0;
	}
	public double getQuantit�DaSottrarreDouble() {
		return Quantit�DaSottrarreDouble;
	}
	
	public double getPrezzoAlKiloDouble() {
		return PrezzoAlKiloDouble;
	}
	


	/**
	 * Create the frame.
	 */
	public FinestraFrutta(Controller c) {
		setTitle("Frutta");
		
		IlController=c;
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 498, 339);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel Frutta_JLb = new JLabel("Frutta");
		Frutta_JLb.setHorizontalAlignment(SwingConstants.CENTER);
		Frutta_JLb.setFont(new Font("Arial Black", Font.PLAIN, 20));
		Frutta_JLb.setBounds(186, 0, 109, 25);
		contentPane.add(Frutta_JLb);
		
		JLabel Quantit�_JLb = new JLabel("Quantit\u00E0 (in chili) che desidera aquistare:");
		Quantit�_JLb.setFont(new Font("Cambria", Font.PLAIN, 14));
		Quantit�_JLb.setBounds(10, 145, 261, 16);
		contentPane.add(Quantit�_JLb);
		
		Quantit�_TF = new JTextField();
		Quantit�_TF.setEditable(false);
		Quantit�_TF.setText("0");
		Quantit�_TF.setFont(new Font("Cambria", Font.PLAIN, 13));
		Quantit�_TF.setHorizontalAlignment(SwingConstants.CENTER);
		Quantit�_TF.setToolTipText("Inserire quantit\u00E0 desiderata");
		Quantit�_TF.setBounds(321, 144, 78, 20);
		contentPane.add(Quantit�_TF);
		Quantit�_TF.setColumns(10);
		
		JButton AvantiButton = new JButton("Avanti");
		AvantiButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

						if((Double.valueOf(Quantit�_TF.getText()))<=(Double.valueOf(DispInMagazzino_TF.getText()))) {
						if(Double.valueOf(Quantit�_TF.getText())!=0) {
						Quantit�_TF.setEditable(false);
						c.prod.setQuantit�(Double.valueOf(Quantit�_TF.getText()));
						setVisible(false);
						IlController.InfoProdotto();
						IlController.ConfermaProdottoWindow.setVisible(true);
							}
						} else {
							c.aqm_dialog.setVisible(true);
						}

				
			}
		});
		AvantiButton.setBounds(318, 265, 154, 23);
		contentPane.add(AvantiButton);
		
		JLabel PrezzoAlKilo_JLb = new JLabel(" Prezzo al Chilo:");
		PrezzoAlKilo_JLb.setFont(new Font("Cambria", Font.PLAIN, 15));
		PrezzoAlKilo_JLb.setBounds(9, 110, 109, 14);
		contentPane.add(PrezzoAlKilo_JLb);
		
		PrezzoAlKilo_TF = new JTextField();
		PrezzoAlKilo_TF.setFont(new Font("Cambria", Font.PLAIN, 13));
		PrezzoAlKilo_TF.setHorizontalAlignment(SwingConstants.CENTER);
		PrezzoAlKilo_TF.setEditable(false);
		PrezzoAlKilo_TF.setBounds(114, 108, 35, 20);
		contentPane.add(PrezzoAlKilo_TF);
		PrezzoAlKilo_TF.setColumns(10);
		
		JLabel DispInMagazzino_JLb = new JLabel("Disponibilit\u00E0 in magazzino:");
		DispInMagazzino_JLb.setFont(new Font("Cambria", Font.PLAIN, 15));
		DispInMagazzino_JLb.setBounds(10, 71, 176, 25);
		contentPane.add(DispInMagazzino_JLb);
		
		DispInMagazzino_TF = new JTextField();
		DispInMagazzino_TF.setFont(new Font("Cambria", Font.PLAIN, 14));
		DispInMagazzino_TF.setHorizontalAlignment(SwingConstants.LEFT);
		DispInMagazzino_TF.setEditable(false);
		DispInMagazzino_TF.setBounds(187, 74, 262, 20);
		contentPane.add(DispInMagazzino_TF);
		DispInMagazzino_TF.setColumns(10);
		

		JButton TornaHomeButton = new JButton("Torna alla home");
		TornaHomeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c.TornaAllaHome();
			}
		});
		TornaHomeButton.setBounds(10, 265, 154, 23);
		contentPane.add(TornaHomeButton);
		
		SimboloEuro = new JTextField();
		SimboloEuro.setEditable(false);
		SimboloEuro.setFont(new Font("Cambria", Font.PLAIN, 13));
		SimboloEuro.setHorizontalAlignment(SwingConstants.CENTER);
		SimboloEuro.setText("\u20AC");
		SimboloEuro.setBounds(148, 108, 18, 20);
		contentPane.add(SimboloEuro);
		SimboloEuro.setColumns(10);
		
		FruttaComboBox.setModel(new DefaultComboBoxModel(new String[] {"Mele", "Pere", "Banane", "Pesche", "Ciliegie", "Albicocche", "Arance"}));
		FruttaComboBox.setToolTipText("");
		FruttaComboBox.setSelectedItem(null);
		FruttaComboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				TipoFrutta = (String) FruttaComboBox.getSelectedItem();
				
				
				if(TipoFrutta.equals("Mele")) {
					IlController.prod = IlController.ConnettiAlDB("Mela");
					PrezzoAlKilo_TF.setText(String.valueOf(IlController.ConnettiAlDB("Mela").getPrezzoAlKilo()));
					disp_tot = IlController.ConnettiAlDB("Mela").getDisponibilit�();
					DispInMagazzino_TF.setText(String.valueOf(disp_tot));

				}
				
				if(TipoFrutta.equals("Pere")) {
					IlController.prod = IlController.ConnettiAlDB("Pera");
					PrezzoAlKilo_TF.setText(String.valueOf(IlController.ConnettiAlDB("Pera").getPrezzoAlKilo()));
					disp_tot = IlController.ConnettiAlDB("Pera").getDisponibilit�();
					DispInMagazzino_TF.setText(String.valueOf(disp_tot));
				}
				
				if(TipoFrutta.equals("Banane")) {
					IlController.prod = IlController.ConnettiAlDB("Banana");
					PrezzoAlKilo_TF.setText(String.valueOf(IlController.ConnettiAlDB("Banana").getPrezzoAlKilo()));
					disp_tot = IlController.ConnettiAlDB("Banana").getDisponibilit�();
					DispInMagazzino_TF.setText(String.valueOf(disp_tot));
				}

				if(TipoFrutta.equals("Pesche")) {
					IlController.prod = IlController.ConnettiAlDB("Pesca");
					PrezzoAlKilo_TF.setText(String.valueOf(IlController.ConnettiAlDB("Pesca").getPrezzoAlKilo()));
					disp_tot = IlController.ConnettiAlDB("Pesca").getDisponibilit�();
					DispInMagazzino_TF.setText(String.valueOf(disp_tot));
				}
				
				if(TipoFrutta.equals("Ciliegie")) {
					IlController.prod = IlController.ConnettiAlDB("Ciliegia");
					PrezzoAlKilo_TF.setText(String.valueOf(IlController.ConnettiAlDB("Ciliegia").getPrezzoAlKilo()));
					disp_tot = IlController.ConnettiAlDB("Ciliegia").getDisponibilit�();
					DispInMagazzino_TF.setText(String.valueOf(disp_tot));
				}
				
				if(TipoFrutta.equals("Albicocche")) {
					IlController.prod = IlController.ConnettiAlDB("Albicocca");
					PrezzoAlKilo_TF.setText(String.valueOf(IlController.ConnettiAlDB("Albicocca").getPrezzoAlKilo()));
					disp_tot = IlController.ConnettiAlDB("Albicocca").getDisponibilit�();
					DispInMagazzino_TF.setText(String.valueOf(disp_tot));
				}
				
				if(TipoFrutta.equals("Arance")) {
					IlController.prod = IlController.ConnettiAlDB("Arancia");
					PrezzoAlKilo_TF.setText(String.valueOf(IlController.ConnettiAlDB("Arancia").getPrezzoAlKilo()));
					disp_tot = IlController.ConnettiAlDB("Arancia").getDisponibilit�();
					DispInMagazzino_TF.setText(String.valueOf(disp_tot));
				}
				
			}
		});
		
		
		FruttaComboBox.setBounds(134, 36, 109, 24);
		contentPane.add(FruttaComboBox);
		
		SelezionaFrutto_TF = new JTextField();
		SelezionaFrutto_TF.setEditable(false);
		SelezionaFrutto_TF.setFont(new Font("Cambria", Font.PLAIN, 14));
		SelezionaFrutto_TF.setText("Seleziona Frutta:");
		SelezionaFrutto_TF.setBounds(10, 36, 121, 25);
		contentPane.add(SelezionaFrutto_TF);
		SelezionaFrutto_TF.setColumns(10);
		
		JButton PiuButton = new JButton("+");
		PiuButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int tmp = Integer.parseInt(Quantit�_TF.getText());
				Quantit�_TF.setText(String.valueOf(tmp+1));		
			}
		});
		PiuButton.setBounds(400, 144, 49, 20);
		contentPane.add(PiuButton);
		
		JButton MenoButton = new JButton("-");
		MenoButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int tmp = Integer.parseInt(Quantit�_TF.getText());
				if(Integer.parseInt(Quantit�_TF.getText())>0) {
				Quantit�_TF.setText(String.valueOf(tmp-1));
				}
			}
		});
		MenoButton.setBounds(270, 144, 49, 20);
		contentPane.add(MenoButton);
		
	}
	
}
