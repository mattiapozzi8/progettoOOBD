package PackageController;
import java.math.BigDecimal;
import java.util.LinkedList;

import PackageDAO.CarrelloDAO;
import PackageDAO.ClienteDAO;
import PackageDAO.ProdottoDAO;
import PackageEntit�.*;
import PackageFinestre.*;
import java.util.ListIterator;
import javax.swing.JDialog;
import javax.swing.JTextField;
public class Controller {
	
	public FinestraRicercaCliente RicercaClienteWindow=new FinestraRicercaCliente(this);
	public FinestraCliente ClienteWindow=new FinestraCliente(this);
	public FinestraCarrello CarrelloWindow=new FinestraCarrello(this);
	public FinestraFrutta FruttaWindow=new FinestraFrutta(this);
	public FinestraUova UovaWindow=new FinestraUova(this);
	public FinestraVerdura VerduraWindow=new FinestraVerdura(this);
	public FinestraLatticini LatticiniWindow=new FinestraLatticini(this);
	public FinestraFarinacei FarinaceiWindow=new FinestraFarinacei(this);
	public FinestraConfezionati ConfezionatiWindow=new FinestraConfezionati(this);
	public ConfermaProdotto ConfermaProdottoWindow = new ConfermaProdotto(this);
	public NewDialog nd = new NewDialog(this);
	public ErrorDialog ed = new ErrorDialog(this);
	public FinestraLogin LoginWindow = new FinestraLogin(this);
	public FinestraRegistrazione RegistrazioneWindow = new FinestraRegistrazione(this);
	public ConfermaDialog cd = new ConfermaDialog(this);
	public double NuovaDisponibilit�;
	public double PrezzoTotale=0.0;
	public HomePage hp = new HomePage(this);
	LinkedList<Prodotto> prodotti = new LinkedList<Prodotto>();
	public ProdottoDAO pr_dao = new ProdottoDAO();
	public String FruttaSelezionata;
	public Prodotto prod = new Prodotto();
	public ClienteDAO clientedao = new ClienteDAO();
	public Cliente cliente = new Cliente();
	public CarrelloDAO carrellodao = new CarrelloDAO();

	
	public static void main(String[] args) {
		Controller c = new Controller();
		
	}
	
	public Controller() {
		hp.setVisible(true);
	}
	
	public void ApriFinestraCarrello() {
		CarrelloWindow.setVisible(true);
		ConfermaProdottoWindow.setVisible(false);
	}
	
	public void ApriFinestraRicercaCliente() {
		RicercaClienteWindow.setVisible(true);
	}
	
	public void ApriFinestraCliente() {
		ClienteWindow.setVisible(true);
	}
	
	public void ApriFinestraUova() {
		UovaWindow.setVisible(true);
		UovaWindow.DispInMagazzino_TF.setText(String.valueOf(ConnettiAlDB("Uova").getDisponibilit�()));
		UovaWindow.PrezzoAlKilo_TF.setText(String.valueOf(ConnettiAlDB("Uova").getPrezzoAlKilo()));
	}
	
	public void ApriFinestraFrutta() {
		FruttaWindow.setVisible(true);
	}
	
	public void ApriFinestraVerdura() {
		VerduraWindow.setVisible(true);
	}
	
	public void ApriFinestraLatticini() {
		LatticiniWindow.setVisible(true);
	}
	
	public void ApriFinestraFarinacei() {
		FarinaceiWindow.setVisible(true);
	}
	
	public void ApriFinestraConfezionati() {
		ConfezionatiWindow.setVisible(true);
	}
	
	public void ApriFinestraLogin() {
		LoginWindow.setVisible(true);
	}
	
	public void setQuantit�TfToZero() {
		FruttaWindow.setQuantit�DaSottrarreDouble(0);
	}

	public void TornaAllaHome() {
		FruttaWindow.setVisible(false);
		VerduraWindow.setVisible(false);
		LatticiniWindow.setVisible(false);
		FarinaceiWindow.setVisible(false);
		ConfezionatiWindow.setVisible(false);
		UovaWindow.setVisible(false);
		ConfermaProdottoWindow.setVisible(false);
		CarrelloWindow.setVisible(false);
		hp.setVisible(true);
	}

	
	public String CalcolaPrezzo() {
		PrezzoTotale=((FruttaWindow.getPrezzoAlKiloDouble())*(FruttaWindow.getQuantit�DaSottrarreDouble()))+PrezzoTotale;
		return ""+PrezzoTotale+"�";
	}
	
	public String SottraiQuantit�() {
		if(FruttaWindow.getQuantit�DaSottrarreDouble()>FruttaWindow.disp_tot) {
			return"Non ci sono abbastanza scorte";
		}
		else {	
			NuovaDisponibilit�=((FruttaWindow.disp_tot)-(FruttaWindow.getQuantit�DaSottrarreDouble()));
			return ""+NuovaDisponibilit�;

		}
	}
	
	public Prodotto ConnettiAlDB(String s) {
		
		Prodotto prod = new Prodotto();
		int i = 0;
		
		prodotti = pr_dao.ConnessioneDB(prod);
		
		for(Prodotto p : prodotti) {
			if(prodotti.get(i).getNomeProdotto().equals(s)) {
				return prodotti.get(i);
			} else {
				i++;
			}
		}
		
		return prod;
		}
	
	public void InfoProdotto() {
		
		ConfermaProdottoWindow.TipoProdotto_lbl.setText(prod.getNomeProdotto());
		ConfermaProdottoWindow.marca_lbl2.setText(prod.getMarca());
		ConfermaProdottoWindow.id_lbl2.setText(String.valueOf(prod.getCodiceID()));
		ConfermaProdottoWindow.prezzo_lbl2.setText(String.valueOf(prod.getPrezzoAlKilo()+"�"));
		ConfermaProdottoWindow.scadenza_lbl2.setText(String.valueOf(prod.getDataDiScadenza()));
		
		if(prod.getTipo().equals("Frutta")) {
			ConfermaProdottoWindow.dynamic1_lbl.setText("Data di raccolta: "+prod.getDataDiRaccolta());
			ConfermaProdottoWindow.dynamic2_lbl.setText("Modalit� di conservazione: "+prod.getModalit�DiConservazione());
		} else {
			if(prod.getTipo().equals("Verdura")) {
				ConfermaProdottoWindow.dynamic1_lbl.setText("Data di raccolta: "+prod.getDataDiRaccolta());
				ConfermaProdottoWindow.dynamic2_lbl.setText("Modalit� di conservazione: "+prod.getModalit�DiConservazione());
			} else {
					if(prod.getTipo().equals("Latticini")) {
						ConfermaProdottoWindow.dynamic1_lbl.setText("Data di produzione: "+prod.getDataDiProduzione());
						ConfermaProdottoWindow.dynamic2_lbl.setText("Paese di condizionamento: "+prod.getPaeseDiCondizionamento());
					} else {
						if(prod.getTipo().equals("Uova")) {
							ConfermaProdottoWindow.dynamic1_lbl.setText("Data di raccolta: "+prod.getDataDiRaccolta());
							ConfermaProdottoWindow.dynamic2_lbl.setText("Data di deposizione: "+prod.getDataDiDeposizione());
						} else {
							if(prod.getTipo().equals("Confezionati")) {
								ConfermaProdottoWindow.dynamic1_lbl.setText("Data di confezionamento: "+prod.getDataConfezionamento());
							}
						}
					}
				}
			}
		}
	
	public void AggiungiAlCarrello(String nome_prodotto) {
		
		
		if (ConfermaProdottoWindow.contatore==0){
			CarrelloWindow.ProdottiInCarrello_lbl.setText(prod.getNomeProdotto()); 
			CarrelloWindow.Quantit�_lbl.setText(String.valueOf(prod.getQuantit�())); 
			CarrelloWindow.Prezzo_lbl.setText(String.valueOf(new BigDecimal((prod.getQuantit�())*(prod.getPrezzoAlKilo())).setScale(2, BigDecimal.ROUND_UP).doubleValue()));
			CarrelloWindow.prezzo_tot = CarrelloWindow.prezzo_tot + (prod.getQuantit�())*(prod.getPrezzoAlKilo());
			}
		if (ConfermaProdottoWindow.contatore==1){
			CarrelloWindow.ProdottiInCarrello2_lbl.setText(prod.getNomeProdotto()); 
			CarrelloWindow.Quantit�_lbl_1.setText(String.valueOf(prod.getQuantit�())); 
			CarrelloWindow.Prezzo_lbl_1.setText(String.valueOf(new BigDecimal((prod.getQuantit�())*(prod.getPrezzoAlKilo())).setScale(2, BigDecimal.ROUND_UP).doubleValue()));
			CarrelloWindow.prezzo_tot = CarrelloWindow.prezzo_tot + (prod.getQuantit�())*(prod.getPrezzoAlKilo());
			}
		if (ConfermaProdottoWindow.contatore==2){
			CarrelloWindow.ProdottiInCarrello3_lbl.setText(prod.getNomeProdotto()); 
			CarrelloWindow.Quantit�_lbl_2.setText(String.valueOf(prod.getQuantit�())); 
			CarrelloWindow.Prezzo_lbl_2.setText(String.valueOf(new BigDecimal((prod.getQuantit�())*(prod.getPrezzoAlKilo())).setScale(2, BigDecimal.ROUND_UP).doubleValue()));
			CarrelloWindow.prezzo_tot = CarrelloWindow.prezzo_tot + (prod.getQuantit�())*(prod.getPrezzoAlKilo());
			}
		if (ConfermaProdottoWindow.contatore==3){
			CarrelloWindow.ProdottiInCarrello4_lbl.setText(prod.getNomeProdotto()); 
			CarrelloWindow.Quantit�_lbl_3.setText(String.valueOf(prod.getQuantit�())); 
			CarrelloWindow.Prezzo_lbl_3.setText(String.valueOf(new BigDecimal((prod.getQuantit�())*(prod.getPrezzoAlKilo())).setScale(2, BigDecimal.ROUND_UP).doubleValue()));
			CarrelloWindow.prezzo_tot = CarrelloWindow.prezzo_tot + (prod.getQuantit�())*(prod.getPrezzoAlKilo());
			}
		if (ConfermaProdottoWindow.contatore==4){
			CarrelloWindow.ProdottiInCarrello5_lbl.setText(prod.getNomeProdotto()); 
			CarrelloWindow.Quantit�_lbl_4.setText(String.valueOf(prod.getQuantit�())); 
			CarrelloWindow.Prezzo_lbl_4.setText(String.valueOf(new BigDecimal((prod.getQuantit�())*(prod.getPrezzoAlKilo())).setScale(2, BigDecimal.ROUND_UP).doubleValue()));
			CarrelloWindow.prezzo_tot = CarrelloWindow.prezzo_tot + (prod.getQuantit�())*(prod.getPrezzoAlKilo());
			}
		if (ConfermaProdottoWindow.contatore==5){
			CarrelloWindow.ProdottiInCarrello6_lbl.setText(prod.getNomeProdotto()); 
			CarrelloWindow.Quantit�_lbl_5.setText(String.valueOf(prod.getQuantit�())); 
			CarrelloWindow.Prezzo_lbl_5.setText(String.valueOf(new BigDecimal((prod.getQuantit�())*(prod.getPrezzoAlKilo())).setScale(2, BigDecimal.ROUND_UP).doubleValue()));
			CarrelloWindow.prezzo_tot = CarrelloWindow.prezzo_tot + (prod.getQuantit�())*(prod.getPrezzoAlKilo());
			}
		if (ConfermaProdottoWindow.contatore==6){
			CarrelloWindow.ProdottiInCarrello7_lbl.setText(prod.getNomeProdotto()); 
			CarrelloWindow.Quantit�_lbl_6.setText(String.valueOf(prod.getQuantit�())); 
			CarrelloWindow.Prezzo_lbl_6.setText(String.valueOf(new BigDecimal((prod.getQuantit�())*(prod.getPrezzoAlKilo())).setScale(2, BigDecimal.ROUND_UP).doubleValue()));
			CarrelloWindow.prezzo_tot = CarrelloWindow.prezzo_tot + (prod.getQuantit�())*(prod.getPrezzoAlKilo());
			}
		if (ConfermaProdottoWindow.contatore==7){
			
			CarrelloWindow.ProdottiInCarrello8_lbl.setText(prod.getNomeProdotto()); 
			CarrelloWindow.Quantit�_lbl_7.setText(String.valueOf(prod.getQuantit�())); 
			CarrelloWindow.Prezzo_lbl_7.setText(String.valueOf(new BigDecimal((prod.getQuantit�())*(prod.getPrezzoAlKilo())).setScale(2, BigDecimal.ROUND_UP).doubleValue()));
			CarrelloWindow.prezzo_tot = CarrelloWindow.prezzo_tot + (prod.getQuantit�())*(prod.getPrezzoAlKilo());
			}
		if (ConfermaProdottoWindow.contatore==8){
			CarrelloWindow.ProdottiInCarrello9_lbl.setText(prod.getNomeProdotto()); 
			CarrelloWindow.Quantit�_lbl_8.setText(String.valueOf(prod.getQuantit�())); 
			CarrelloWindow.Prezzo_lbl_8.setText(String.valueOf(new BigDecimal((prod.getQuantit�())*(prod.getPrezzoAlKilo())).setScale(2, BigDecimal.ROUND_UP).doubleValue()));
			CarrelloWindow.prezzo_tot = CarrelloWindow.prezzo_tot + (prod.getQuantit�())*(prod.getPrezzoAlKilo());
			}
		if (ConfermaProdottoWindow.contatore==9){
			CarrelloWindow.ProdottiInCarrello10_lbl.setText(prod.getNomeProdotto()); 
			CarrelloWindow.Quantit�_lbl_9.setText(String.valueOf(prod.getQuantit�())); 
			CarrelloWindow.Prezzo_lbl_9.setText(String.valueOf(new BigDecimal((prod.getQuantit�())*(prod.getPrezzoAlKilo())).setScale(2, BigDecimal.ROUND_UP).doubleValue()));
			CarrelloWindow.prezzo_tot = CarrelloWindow.prezzo_tot + (prod.getQuantit�())*(prod.getPrezzoAlKilo());
			}
		if (ConfermaProdottoWindow.contatore==10){
			CarrelloWindow.ProdottiInCarrello11_lbl.setText(prod.getNomeProdotto()); 
			CarrelloWindow.Quantit�_lbl_10.setText(String.valueOf(prod.getQuantit�())); 
			CarrelloWindow.Prezzo_lbl_10.setText(String.valueOf(new BigDecimal((prod.getQuantit�())*(prod.getPrezzoAlKilo())).setScale(2, BigDecimal.ROUND_UP).doubleValue()));
			CarrelloWindow.prezzo_tot = CarrelloWindow.prezzo_tot + (prod.getQuantit�())*(prod.getPrezzoAlKilo());
			}
		if (ConfermaProdottoWindow.contatore==11){
			CarrelloWindow.ProdottiInCarrello12_lbl.setText(prod.getNomeProdotto()); 
			CarrelloWindow.Quantit�_lbl_11.setText(String.valueOf(prod.getQuantit�())); 
			CarrelloWindow.Prezzo_lbl_11.setText(String.valueOf(new BigDecimal((prod.getQuantit�())*(prod.getPrezzoAlKilo())).setScale(2, BigDecimal.ROUND_UP).doubleValue()));
			CarrelloWindow.prezzo_tot = CarrelloWindow.prezzo_tot + (prod.getQuantit�())*(prod.getPrezzoAlKilo());
			}
		if (ConfermaProdottoWindow.contatore==12){
			CarrelloWindow.ProdottiInCarrello13_lbl.setText(prod.getNomeProdotto()); 
			CarrelloWindow.Quantit�_lbl_12.setText(String.valueOf(prod.getQuantit�())); 
			CarrelloWindow.Prezzo_lbl_12.setText(String.valueOf(new BigDecimal((prod.getQuantit�())*(prod.getPrezzoAlKilo())).setScale(2, BigDecimal.ROUND_UP).doubleValue()));
			CarrelloWindow.prezzo_tot = CarrelloWindow.prezzo_tot + (prod.getQuantit�())*(prod.getPrezzoAlKilo());
			}
		if (ConfermaProdottoWindow.contatore==13){
			CarrelloWindow.ProdottiInCarrello14_lbl.setText(prod.getNomeProdotto());
			CarrelloWindow.Quantit�_lbl_13.setText(String.valueOf(prod.getQuantit�())); 
			CarrelloWindow.Prezzo_lbl_13.setText(String.valueOf(new BigDecimal((prod.getQuantit�())*(prod.getPrezzoAlKilo())).setScale(2, BigDecimal.ROUND_UP).doubleValue()));
			CarrelloWindow.prezzo_tot = CarrelloWindow.prezzo_tot + (prod.getQuantit�())*(prod.getPrezzoAlKilo());
			}
		if (ConfermaProdottoWindow.contatore==14){
			CarrelloWindow.ProdottiInCarrello15_lbl.setText(prod.getNomeProdotto()); 
			CarrelloWindow.Quantit�_lbl_14.setText(String.valueOf(prod.getQuantit�())); 
			CarrelloWindow.Prezzo_lbl_14.setText(String.valueOf(new BigDecimal((prod.getQuantit�())*(prod.getPrezzoAlKilo())).setScale(2, BigDecimal.ROUND_UP).doubleValue()));
			CarrelloWindow.prezzo_tot = CarrelloWindow.prezzo_tot + (prod.getQuantit�())*(prod.getPrezzoAlKilo());
			}

			CarrelloWindow.Prezzo_tot_lbl.setText(String.valueOf(new BigDecimal(CarrelloWindow.prezzo_tot).setScale(2, BigDecimal.ROUND_UP).doubleValue())+"�");
		
//		int i;
		
//		prod.IlCarrello.ProdottiInCarrello.add(ConnettiAlDB(nome_prodotto));
//		
//		for(i=0; i<prod.IlCarrello.ProdottiInCarrello.size(); i++) {
//			CarrelloWindow.ProdottiInCarrello_lbl.setText(prod.IlCarrello.ProdottiInCarrello.get(i).getNomeProdotto()+"\n");
//			System.out.println(prod.IlCarrello.ProdottiInCarrello.size());
//		}
//	
	
	}
	
	public void ControlloCredenziali(String user, String pass) {	
		clientedao.controllo(user, pass);
		if(clientedao.exists()){
		clientedao.flag = 0;	
		LoginWindow.setVisible(false);
		cd.setVisible(true);
		}
		else {
		nd.setVisible(true);
		}
		
	}
	
	public void RieseguiLogin() {
			
			LoginWindow.SvuotaCampi();
			nd.setVisible(false);
			
		}
		

	public void SvuotaCarrello() {
		CarrelloWindow.ProdottiInCarrello_lbl.setText(""); 
		CarrelloWindow.Quantit�_lbl.setText(""); 
		CarrelloWindow.Prezzo_lbl.setText("");
		CarrelloWindow.ProdottiInCarrello2_lbl.setText(""); 
		CarrelloWindow.Quantit�_lbl_1.setText(""); 
		CarrelloWindow.Prezzo_lbl_1.setText("");
		CarrelloWindow.ProdottiInCarrello3_lbl.setText(""); 
		CarrelloWindow.Quantit�_lbl_2.setText(""); 
		CarrelloWindow.Prezzo_lbl_2.setText("");
		CarrelloWindow.ProdottiInCarrello3_lbl.setText(""); 
		CarrelloWindow.Quantit�_lbl_2.setText(""); 
		CarrelloWindow.Prezzo_lbl_2.setText("");
		CarrelloWindow.ProdottiInCarrello4_lbl.setText(""); 
		CarrelloWindow.Quantit�_lbl_3.setText(""); 
		CarrelloWindow.Prezzo_lbl_3.setText("");
		CarrelloWindow.ProdottiInCarrello5_lbl.setText(""); 
		CarrelloWindow.Quantit�_lbl_4.setText(""); 
		CarrelloWindow.Prezzo_lbl_4.setText("");
		CarrelloWindow.ProdottiInCarrello6_lbl.setText(""); 
		CarrelloWindow.Quantit�_lbl_5.setText(""); 
		CarrelloWindow.Prezzo_lbl_5.setText("");
		CarrelloWindow.ProdottiInCarrello7_lbl.setText(""); 
		CarrelloWindow.Quantit�_lbl_6.setText(""); 
		CarrelloWindow.Prezzo_lbl_6.setText("");
		CarrelloWindow.ProdottiInCarrello8_lbl.setText(""); 
		CarrelloWindow.Quantit�_lbl_7.setText(""); 
		CarrelloWindow.Prezzo_lbl_7.setText("");
		CarrelloWindow.ProdottiInCarrello9_lbl.setText(""); 
		CarrelloWindow.Quantit�_lbl_8.setText(""); 
		CarrelloWindow.Prezzo_lbl_8.setText("");
		CarrelloWindow.ProdottiInCarrello10_lbl.setText(""); 
		CarrelloWindow.Quantit�_lbl_9.setText(""); 
		CarrelloWindow.Prezzo_lbl_9.setText("");
		CarrelloWindow.ProdottiInCarrello11_lbl.setText(""); 
		CarrelloWindow.Quantit�_lbl_10.setText(""); 
		CarrelloWindow.Prezzo_lbl_10.setText("");
		CarrelloWindow.ProdottiInCarrello12_lbl.setText(""); 
		CarrelloWindow.Quantit�_lbl_11.setText(""); 
		CarrelloWindow.Prezzo_lbl_11.setText("");
		CarrelloWindow.ProdottiInCarrello13_lbl.setText(""); 
		CarrelloWindow.Quantit�_lbl_12.setText(""); 
		CarrelloWindow.Prezzo_lbl_12.setText("");
		CarrelloWindow.ProdottiInCarrello14_lbl.setText(""); 
		CarrelloWindow.Quantit�_lbl_13.setText(""); 
		CarrelloWindow.Prezzo_lbl_13.setText("");
		CarrelloWindow.ProdottiInCarrello15_lbl.setText(""); 
		CarrelloWindow.Quantit�_lbl_14.setText(""); 
		CarrelloWindow.Prezzo_lbl_14.setText("");
		ConfermaProdottoWindow.contatore = 0;
		CarrelloWindow.Prezzo_tot_lbl.setText("0");
		CarrelloWindow.prezzo_tot = 0;
	}
		
}



