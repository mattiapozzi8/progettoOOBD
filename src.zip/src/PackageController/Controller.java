package PackageController;
import java.util.LinkedList;
import PackageDAO.FruttaDAO;
import PackageEntit�.*;
import PackageFinestre.*;

import java.util.ListIterator;
import javax.swing.JDialog;
import javax.swing.JTextField;
public class Controller {
	
	public FinestraRicercaCliente RicercaClienteWindow=new FinestraRicercaCliente(this);
	public FinestraCliente ClienteWindow=new FinestraCliente(this);
	public FinestraCarrello CarrelloWindow=new FinestraCarrello(this);
	public FinestraFrutta FruttaWindow=new FinestraFrutta(this);
	public FinestraUova UovaWindow=new FinestraUova(this);
	public FinestraVerdura VerduraWindow=new FinestraVerdura(this);
	public FinestraLatticini LatticiniWindow=new FinestraLatticini(this);
	public FinestraFarinacei FarinaceiWindow=new FinestraFarinacei(this);
	public FinestraConfezionati ConfezionatiWindow=new FinestraConfezionati(this);
	public ConfermaFrutta ConfermaFruttaWindow = new ConfermaFrutta(this);
	ErroreCfJDialog PopUp=new ErroreCfJDialog(this);
	public double NuovaDisponibilit�;
	public double PrezzoTotale=0.0;
	public HomePage hp = new HomePage(this);
	LinkedList<Frutta> frutti = new LinkedList<Frutta>();
	FruttaDAO fr_dao = new FruttaDAO();
	public String FruttaSelezionata;
	public Prodotto prod = new Prodotto();
	
	
	
	public static void main(String[] args) {
		Controller c = new Controller();
		
	}
	
	public Controller() {
		hp.setVisible(true);
	}
	
	public void ApriFinestraCarrello() {
		CarrelloWindow.setVisible(true);
	}
	
	public void ApriFinestraRicercaCliente() {
		RicercaClienteWindow.setVisible(true);
	}
	
	public void ApriFinestraCliente() {
		ClienteWindow.setVisible(true);
	}
	
	public void ApriFinestraUova() {
		UovaWindow.setVisible(true);
	}
	
	public void ApriFinestraFrutta() {
		FruttaWindow.setVisible(true);
	}
	
	public void ApriFinestraVerdura() {
		VerduraWindow.setVisible(true);
	}
	
	public void ApriFinestraLatticini() {
		LatticiniWindow.setVisible(true);
	}
	
	public void ApriFinestraFarinacei() {
		FarinaceiWindow.setVisible(true);
	}
	
	public void ApriFinestraConfezionati() {
		ConfezionatiWindow.setVisible(true);
	}
	
	public void ApriJDialogErroreCf() {
		try {
			PopUp.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			PopUp.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void ChiudiJDialogErroreCf() {
		PopUp.setVisible(false);
	}
	
	
	public void setQuantit�TfToZero() {
		FruttaWindow.setQuantit�DaSottrarreDouble(0);
	}
	

	
	public void TornaAllaHome() {
		FruttaWindow.setVisible(false);
		VerduraWindow.setVisible(false);
		LatticiniWindow.setVisible(false);
		FarinaceiWindow.setVisible(false);
		ConfezionatiWindow.setVisible(false);
		UovaWindow.setVisible(false);
		ConfermaFruttaWindow.setVisible(false);
		hp.setVisible(true);
	}

	
	public String CalcolaPrezzo() {
		PrezzoTotale=((FruttaWindow.getPrezzoAlKiloDouble())*(FruttaWindow.getQuantit�DaSottrarreDouble()))+PrezzoTotale;
		return ""+PrezzoTotale+"�";
	}
	
	public String SottraiQuantit�() {
		if(FruttaWindow.getQuantit�DaSottrarreDouble()>FruttaWindow.disp_tot) {
			return"Non ci sono abbastanza scorte";
		}
		else {	
			NuovaDisponibilit�=((FruttaWindow.disp_tot)-(FruttaWindow.getQuantit�DaSottrarreDouble()));
			return ""+NuovaDisponibilit�;

		}
	}
	
	public Frutta ConnettiAlDB(String s) {
		
		Frutta fr = new Frutta();
		int i = 0;
		
		frutti = fr_dao.ConnessioneDB(fr);
		
		for(Frutta f : frutti) {
			if(frutti.get(i).getNomeProdotto().equals(s)) {
				return frutti.get(i);
			} else {
				i++;
			}
		}
		
		return fr;
		}
	
	public void InfoProdotto() {
		
		ConfermaFruttaWindow.TipoFrutta_TF.setText(prod.getNomeProdotto());
		ConfermaFruttaWindow.marca_TF.setText(prod.getMarca());
		ConfermaFruttaWindow.id_TF.setText(String.valueOf(prod.getCodiceID()));
		ConfermaFruttaWindow.prezzo_TF.setText(String.valueOf(prod.getPrezzoAlKilo()));
		ConfermaFruttaWindow.scadenza_TF.setText(String.valueOf(prod.getDataDiScadenza()));
	}
	
	
}


