package PackageFinestre;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import PackageController.Controller;
import PackageEntit�.Frutta;

import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JTextField;

public class ConfermaFrutta extends JFrame {

	private JPanel contentPane;
	Controller IlController;
	Frutta fruit = new Frutta();
	public JTextField TipoFrutta_TF;


	public ConfermaFrutta(Controller c) {
		IlController = c;
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		TipoFrutta_TF = new JTextField();
		TipoFrutta_TF.setFont(new Font("Cambria", Font.PLAIN, 18));
		TipoFrutta_TF.setHorizontalAlignment(SwingConstants.CENTER);
		TipoFrutta_TF.setEditable(false);
		TipoFrutta_TF.setBounds(10, 11, 414, 32);
		contentPane.add(TipoFrutta_TF);
		TipoFrutta_TF.setColumns(10);
	}
}
